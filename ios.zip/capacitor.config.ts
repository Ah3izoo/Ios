import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.looker.sales.studio',
  appName: 'Looker Sales Studio',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
  },
};

export default config;
