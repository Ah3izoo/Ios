# دليل بناء وتحميل تطبيق أندرويد (APK) عبر GitHub Actions
# How to Build & Download Android APK on GitHub

تم إعداد هذا المستودع بالكامل مع بيئة **Capacitor** ونظام **GitHub Actions CI/CD** لبناء ملف التثبيت **Android APK** تلقائياً ومجاناً.

---

## 🚀 الطريقة الأولى: البناء التلقائي عبر GitHub (بدون الحاجة لتثبيت أي برامج على جهازك)

### 1. رفع المشروع إلى مستودعك في GitHub:
افتح موجه الأوامر (Terminal) في مجلد المشروع وقم بتنفيذ الأوامر التالية:

```bash
git init
git add .
git commit -m "Initial commit with Looker Sales Studio & Android APK setup"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY.git
git push -u origin main
```
*(استبدل `YOUR_USERNAME` و `YOUR_REPOSITORY` ببيانات حسابك في GitHub)*

---

### 2. متابعة البناء التلقائي في GitHub:
1. اذهب إلى صفحة المستودع الخاص بك على GitHub في المتصفح.
2. اضغط على تبويب **Actions** في الشريط العلوي للمستودع.
3. ستجد سير العمل بعنوان **`Build Android APK`** قد بدأ العمل تلقائياً (أيقونة صفراء تدور).
4. يستغرق البناء عادة ما بين **2 إلى 3 دقائق**.

---

### 3. تحميل ملف الـ APK:
1. بمجرد انتهاء البناء وظهور علامة الصح الخضراء `✓`، اضغط على اسم العملية (مثلاً: *Build Android APK*).
2. انزل إلى أسفل الصفحة حتى تصل إلى قسم **Artifacts** (المخرجات).
3. اضغط على رابط:
   ```
   LookerSalesStudio-Android-APK
   ```
4. سيتم تحميل ملف مضغوط يحتوي على **`app-debug.apk`**.
5. انقله إلى هاتفك الأندرويد وافتحه لتثبيت التطبيق مباشرة!

---

## 🛠️ الطريقة الثانية: تشغيل البناء يدوياً من GitHub (Manual Trigger)
إذا قمت بتعديل الأسعار أو البيانات وأردت بناء APK جديد دون عمل Commit جديد:
1. ادخل على تبويب **Actions** في GitHub.
2. اختر من القائمة الجانبية سير العمل **Build Android APK**.
3. اضغط على زر **Run workflow** الأزرق على اليمين.
4. انتظر دقيقتين وقم بتحميل الـ APK الجديد من قسم Artifacts.

---

## 💻 الطريقة الثالثة: البناء محلياً على جهاز الكمبيوتر (Local Build)
إذا كان لديك **Android Studio** أو **Android SDK** و **Java JDK 17** على جهازك:

```bash
# 1. تثبيت الحزم وبناء ملفات الويب ومزامنتها مع أندرويد
npm run cap:build

# 2. بناء ملف الـ APK عبر Gradle
cd android
./gradlew assembleDebug

# مسار ملف الـ APK الناتج:
# android/app/build/outputs/apk/debug/app-debug.apk
```

أو يمكنك فتح المشروع في Android Studio لتشغيله على المحاكي:
```bash
npm run cap:open
```

---

## 📱 مميزات ملف الـ APK المدمج:
- يعمل كتطبيق أندرويد مستقل بشاشة كاملة مع دعم اللمس والإيماءات.
- يحتوي على قاعدة البيانات الكاملة لجميع الأصناف الـ 23.
- دعم العمل دون اتصال بالإنترنت وحفظ التغييرات محلياً على الهاتف.
- يدعم عملة الجنيه السوداني (ج.س) وكافة العملات الأخرى.
