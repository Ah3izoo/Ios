import React, { useEffect, useMemo, useState } from 'react';
import { AddSaleModal } from './components/AddSaleModal';
import { ApkBuildModal } from './components/ApkBuildModal';
import { ItemQuantityDonut } from './components/Charts/ItemQuantityDonut';
import { TimeSeriesChart } from './components/Charts/TimeSeriesChart';
import { TopCustomersChart } from './components/Charts/TopCustomersChart';
import { CustomerSalesTable } from './components/CustomerSalesTable';
import { DataSourceManager } from './components/DataSourceManager';
import { FilterBar } from './components/FilterBar';
import { InvoicePdfModal } from './components/InvoicePdfModal';
import { ItemSalesTable } from './components/ItemSalesTable';
import { LookerStudioGuide } from './components/LookerStudioGuide';
import { Navbar } from './components/Navbar';
import { PriceManagerModal } from './components/PriceManagerModal';
import { Scorecards } from './components/Scorecards';
import {
  APP_NAME,
  DEFAULT_SALES_REP,
  MASTER_PRODUCT_CATALOG,
  SUPPLIER_LINE,
} from './data/productCatalog';
import { INITIAL_SALES_DATA } from './data/sampleData';
import {
  CurrencyCode,
  CustomerSummary,
  FilterState,
  ItemSummary,
  ProductItem,
  SalesRecord,
  TimeSeriesPoint,
} from './types';
import { exportToCSV } from './utils/csvHelper';
import { formatCurrency, formatNumber } from './utils/formatters';

const STORAGE_KEY_SALES = 'looker_sales_batterjee_v4';
const STORAGE_KEY_PRICES = 'looker_prices_batterjee_v4';

export default function App() {
  // 1. Data State with LocalStorage
  const [salesData, setSalesData] = useState<SalesRecord[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY_SALES);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // fallback
    }
    return INITIAL_SALES_DATA;
  });

  // 2. Product Catalog / Price List State with LocalStorage
  const [catalog, setCatalog] = useState<ProductItem[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY_PRICES);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // fallback
    }
    return MASTER_PRODUCT_CATALOG;
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_SALES, JSON.stringify(salesData));
    } catch {}
  }, [salesData]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_PRICES, JSON.stringify(catalog));
    } catch {}
  }, [catalog]);

  // 3. Navigation & Modals UI state
  const [activeTab, setActiveTab] = useState<
    'dashboard' | 'customers' | 'items' | 'dataSource' | 'lookerGuide'
  >('dashboard');
  const [currency, setCurrency] = useState<CurrencyCode>('SDG');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isPriceModalOpen, setIsPriceModalOpen] = useState(false);
  const [isApkModalOpen, setIsApkModalOpen] = useState(false);
  const [isInvoiceModalOpen, setIsInvoiceModalOpen] = useState(false);
  const [selectedInvoiceRecord, setSelectedInvoiceRecord] = useState<SalesRecord | null>(null);

  // 4. Filter State
  const [filters, setFilters] = useState<FilterState>({
    dateRange: 'all',
    startDate: '',
    endDate: '',
    selectedCustomer: '',
    selectedCategory: '',
    selectedItem: '',
    selectedSalesRep: '',
    searchQuery: '',
  });

  // Reset filters
  const handleResetFilters = () => {
    setFilters({
      dateRange: 'all',
      startDate: '',
      endDate: '',
      selectedCustomer: '',
      selectedCategory: '',
      selectedItem: '',
      selectedSalesRep: '',
      searchQuery: '',
    });
  };

  // Lists for Dropdowns
  const customersList = useMemo(() => {
    const set = new Set<string>();
    salesData.forEach((s) => s.customerName && set.add(s.customerName));
    return Array.from(set).sort((a, b) => a.localeCompare(b, 'ar'));
  }, [salesData]);

  const categoriesList = useMemo(() => {
    const set = new Set<string>();
    salesData.forEach((s) => s.category && set.add(s.category));
    return Array.from(set).sort((a, b) => a.localeCompare(b, 'ar'));
  }, [salesData]);

  const itemsList = useMemo(() => {
    const set = new Set<string>();
    catalog.forEach((p) => set.add(p.productName));
    salesData.forEach((s) => s.itemName && set.add(s.itemName));
    return Array.from(set).sort((a, b) => a.localeCompare(b, 'ar'));
  }, [catalog, salesData]);

  const salesRepsList = useMemo(() => {
    const set = new Set<string>();
    set.add(DEFAULT_SALES_REP);
    salesData.forEach((s) => s.salesRep && set.add(s.salesRep));
    return Array.from(set);
  }, [salesData]);

  // Determine latest date in dataset for relative filters
  const latestDateInDataset = useMemo(() => {
    if (salesData.length === 0) return new Date();
    const sorted = [...salesData].sort((a, b) => b.date.localeCompare(a.date));
    return new Date(sorted[0].date);
  }, [salesData]);

  // Filtered dataset
  const filteredData = useMemo(() => {
    return salesData.filter((item) => {
      // 1. Sales Rep
      if (filters.selectedSalesRep && item.salesRep !== filters.selectedSalesRep) {
        return false;
      }
      // 2. Customer
      if (filters.selectedCustomer && item.customerName !== filters.selectedCustomer) {
        return false;
      }
      // 3. Category
      if (filters.selectedCategory && item.category !== filters.selectedCategory) {
        return false;
      }
      // 4. Item
      if (filters.selectedItem && item.itemName !== filters.selectedItem) {
        return false;
      }
      // 5. Search query
      if (filters.searchQuery) {
        const q = filters.searchQuery.toLowerCase();
        const matches =
          item.customerName.toLowerCase().includes(q) ||
          item.itemName.toLowerCase().includes(q) ||
          (item.salesRep && item.salesRep.toLowerCase().includes(q)) ||
          (item.genericName && item.genericName.toLowerCase().includes(q)) ||
          (item.orderId && item.orderId.toLowerCase().includes(q));
        if (!matches) return false;
      }

      // 6. Date Range
      if (filters.dateRange !== 'all') {
        const itemDate = new Date(item.date);
        const refDate = latestDateInDataset;

        if (filters.dateRange === '7days') {
          const past = new Date(refDate);
          past.setDate(past.getDate() - 7);
          if (itemDate < past) return false;
        } else if (filters.dateRange === '30days') {
          const past = new Date(refDate);
          past.setDate(past.getDate() - 30);
          if (itemDate < past) return false;
        } else if (filters.dateRange === '90days') {
          const past = new Date(refDate);
          past.setDate(past.getDate() - 90);
          if (itemDate < past) return false;
        } else if (filters.dateRange === 'thisMonth') {
          if (
            itemDate.getFullYear() !== refDate.getFullYear() ||
            itemDate.getMonth() !== refDate.getMonth()
          ) {
            return false;
          }
        } else if (filters.dateRange === 'lastMonth') {
          const prevMonth = refDate.getMonth() === 0 ? 11 : refDate.getMonth() - 1;
          const prevYear =
            refDate.getMonth() === 0 ? refDate.getFullYear() - 1 : refDate.getFullYear();
          if (itemDate.getFullYear() !== prevYear || itemDate.getMonth() !== prevMonth) {
            return false;
          }
        } else if (filters.dateRange === 'custom') {
          if (filters.startDate && item.date < filters.startDate) return false;
          if (filters.endDate && item.date > filters.endDate) return false;
        }
      }

      return true;
    });
  }, [salesData, filters, latestDateInDataset]);

  // 5. Aggregated KPIs
  const totalRevenue = useMemo(() => {
    return filteredData.reduce((acc, r) => acc + (r.totalSales || 0), 0);
  }, [filteredData]);

  const totalQuantity = useMemo(() => {
    return filteredData.reduce((acc, r) => acc + (r.quantity || 0), 0);
  }, [filteredData]);

  const distinctCustomers = useMemo(() => {
    const set = new Set<string>();
    filteredData.forEach((r) => r.customerName && set.add(r.customerName));
    return set.size;
  }, [filteredData]);

  const orderCount = useMemo(() => {
    return filteredData.length;
  }, [filteredData]);

  const averageOrderValue = useMemo(() => {
    return orderCount > 0 ? totalRevenue / orderCount : 0;
  }, [totalRevenue, orderCount]);

  // 6. Customer Summaries
  const customerSummaries: CustomerSummary[] = useMemo(() => {
    const map = new Map<
      string,
      {
        totalSales: number;
        totalQuantity: number;
        orders: Set<string>;
        segment?: string;
      }
    >();

    filteredData.forEach((r) => {
      const name = r.customerName || 'غير محدد';
      const entry = map.get(name) || {
        totalSales: 0,
        totalQuantity: 0,
        orders: new Set<string>(),
        segment: r.customerSegment,
      };

      entry.totalSales += r.totalSales;
      entry.totalQuantity += r.quantity;
      entry.orders.add(r.orderId || r.id);
      if (r.customerSegment) entry.segment = r.customerSegment;

      map.set(name, entry);
    });

    const result: CustomerSummary[] = [];
    map.forEach((val, name) => {
      const orders = val.orders.size || 1;
      result.push({
        customerName: name,
        segment: val.segment,
        totalSales: val.totalSales,
        totalQuantity: val.totalQuantity,
        orderCount: orders,
        avgOrderValue: val.totalSales / orders,
        percentageOfTotal: totalRevenue > 0 ? val.totalSales / totalRevenue : 0,
      });
    });

    return result.sort((a, b) => b.totalSales - a.totalSales);
  }, [filteredData, totalRevenue]);

  // 7. Item Summaries
  const itemSummaries: ItemSummary[] = useMemo(() => {
    const map = new Map<
      string,
      {
        category: string;
        totalQuantity: number;
        totalSales: number;
      }
    >();

    filteredData.forEach((r) => {
      const name = r.itemName || 'صنف غير محدد';
      const entry = map.get(name) || {
        category: r.category || 'عام',
        totalQuantity: 0,
        totalSales: 0,
      };

      entry.totalQuantity += r.quantity;
      entry.totalSales += r.totalSales;
      map.set(name, entry);
    });

    const result: ItemSummary[] = [];
    map.forEach((val, name) => {
      const avgPrice = val.totalQuantity > 0 ? val.totalSales / val.totalQuantity : 0;
      result.push({
        itemName: name,
        category: val.category,
        totalQuantity: val.totalQuantity,
        avgUnitPrice: avgPrice,
        totalSales: val.totalSales,
        percentageOfTotal: totalRevenue > 0 ? val.totalSales / totalRevenue : 0,
      });
    });

    return result.sort((a, b) => b.totalSales - a.totalSales);
  }, [filteredData, totalRevenue]);

  // 8. Time Series Points
  const timeSeriesPoints: TimeSeriesPoint[] = useMemo(() => {
    const map = new Map<
      string,
      {
        sales: number;
        quantity: number;
        orders: number;
      }
    >();

    const sorted = [...filteredData].sort((a, b) => a.date.localeCompare(b.date));

    sorted.forEach((r) => {
      const key = r.date;
      const cur = map.get(key) || { sales: 0, quantity: 0, orders: 0 };
      cur.sales += r.totalSales;
      cur.quantity += r.quantity;
      cur.orders += 1;
      map.set(key, cur);
    });

    const result: TimeSeriesPoint[] = [];
    map.forEach((v, k) => {
      result.push({
        dateKey: k,
        label: k.slice(5),
        sales: v.sales,
        quantity: v.quantity,
        orders: v.orders,
      });
    });

    return result;
  }, [filteredData]);

  // Add Sale handler
  const handleAddSale = (newRec: Omit<SalesRecord, 'id'>) => {
    const rec: SalesRecord = {
      ...newRec,
      id: `rec-${Date.now()}`,
    };
    setSalesData((prev) => [rec, ...prev]);
  };

  // Save updated catalog prices (and optionally update existing sales records)
  const handleSaveCatalog = (updatedCatalog: ProductItem[], applyToExistingSales: boolean) => {
    setCatalog(updatedCatalog);

    if (applyToExistingSales) {
      const priceMap = new Map<string, number>();
      updatedCatalog.forEach((p) => {
        priceMap.set(p.productName.toLowerCase(), p.currentPrice);
      });

      setSalesData((prev) =>
        prev.map((rec) => {
          const newPrice = priceMap.get(rec.itemName.toLowerCase());
          if (newPrice !== undefined && newPrice !== rec.unitPrice) {
            return {
              ...rec,
              unitPrice: newPrice,
              totalSales: rec.quantity * newPrice,
            };
          }
          return rec;
        })
      );
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* Top Bar Contract (1 line wordmark, 4-5 links, 1 action) */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currency={currency}
        setCurrency={setCurrency}
        onOpenAddModal={() => setIsAddModalOpen(true)}
        onOpenPriceModal={() => setIsPriceModalOpen(true)}
        onOpenApkModal={() => setIsApkModalOpen(true)}
        onOpenInvoiceModal={() => {
          setSelectedInvoiceRecord(salesData[0] || null);
          setIsInvoiceModalOpen(true);
        }}
        recordCount={salesData.length}
        salesRepName={DEFAULT_SALES_REP}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Sales Rep & Company Executive Header Strip */}
        <div className="mb-6 bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-start sm:items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-blue-600 text-white font-bold text-lg flex items-center justify-center shrink-0 shadow-sm">
              م م
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-slate-900">
                  المندوب: {DEFAULT_SALES_REP}
                </h2>
                <span className="text-[11px] font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
                  مندوب مبيعات معتمد
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                خط منتجات {SUPPLIER_LINE} · لوحة متابعة مبيعات الأدوية
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 pt-2 md:pt-0 border-t md:border-t-0 border-slate-100">
            <button
              onClick={() => {
                setSelectedInvoiceRecord(salesData[0] || null);
                setIsInvoiceModalOpen(true);
              }}
              className="px-3.5 py-2 text-xs font-semibold text-purple-800 bg-purple-50 hover:bg-purple-100 border border-purple-300 rounded-lg transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <span>طباعة فاتورة PDF 📄</span>
            </button>
            <button
              onClick={() => setIsApkModalOpen(true)}
              className="px-3.5 py-2 text-xs font-bold text-slate-800 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <span>تطبيق الآيفون (iOS) 🍏</span>
            </button>
            <button
              onClick={() => setIsPriceModalOpen(true)}
              className="px-3.5 py-2 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100/80 border border-blue-200 rounded-lg transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <span>تعديل قائمة الأسعار ({catalog.length} صنف)</span>
            </button>
            <button
              onClick={() => setIsAddModalOpen(true)}
              className="px-4 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm transition-colors cursor-pointer"
            >
              + إضافة فاتورة مبيعات
            </button>
          </div>
        </div>

        {/* Global Filter Bar (shown on dashboard, customers, and items tabs) */}
        {activeTab !== 'dataSource' && activeTab !== 'lookerGuide' && (
          <FilterBar
            filters={filters}
            setFilters={setFilters}
            customersList={customersList}
            categoriesList={categoriesList}
            itemsList={itemsList}
            salesRepsList={salesRepsList}
            totalFiltered={filteredData.length}
            totalRecords={salesData.length}
            onReset={handleResetFilters}
            onExportCSV={() => exportToCSV(filteredData)}
            onPrint={handlePrint}
          />
        )}

        {/* ================= TAB 1: EXECUTIVE DASHBOARD ================= */}
        {activeTab === 'dashboard' && (
          <div className="space-y-6">
            {/* 1. Scorecards / KPIs */}
            <Scorecards
              totalRevenue={totalRevenue}
              totalQuantity={totalQuantity}
              distinctCustomers={distinctCustomers}
              orderCount={orderCount}
              averageOrderValue={averageOrderValue}
              currency={currency}
            />

            {/* 2. Primary Charts Grid: Time Series + Top 5 Customers */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              <div className="lg:col-span-7">
                <TimeSeriesChart data={timeSeriesPoints} currency={currency} />
              </div>
              <div className="lg:col-span-5">
                <TopCustomersChart
                  customers={customerSummaries}
                  currency={currency}
                  selectedCustomer={filters.selectedCustomer}
                  onSelectCustomer={(c) =>
                    setFilters((prev) => ({ ...prev, selectedCustomer: c }))
                  }
                />
              </div>
            </div>

            {/* 3. Secondary Chart: Donut Chart for Quantities */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              <div className="lg:col-span-6">
                <ItemQuantityDonut
                  items={itemSummaries}
                  currency={currency}
                  selectedItem={filters.selectedItem}
                  onSelectItem={(item) =>
                    setFilters((prev) => ({ ...prev, selectedItem: item }))
                  }
                />
              </div>

              {/* Category Performance Card */}
              <div className="lg:col-span-6 bg-white rounded-xl border border-slate-200/90 p-5 shadow-xs flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                      <span>توزيع المبيعات حسب الفئات (Category Breakdown)</span>
                      <span className="text-[10px] text-slate-400 font-mono">Category Dimension</span>
                    </h3>
                    <span className="text-xs text-slate-500 font-medium">أصناف {APP_NAME}</span>
                  </div>
                  <p className="text-xs text-slate-500 mb-4">
                    مساهمة كل قطاع علاجي في إجمالي المبيعات المحققة
                  </p>

                  <div className="space-y-3">
                    {categoriesList.map((cat) => {
                      const catItems = filteredData.filter((r) => r.category === cat);
                      const catSales = catItems.reduce((s, r) => s + r.totalSales, 0);
                      const catQty = catItems.reduce((s, r) => s + r.quantity, 0);
                      const pct = totalRevenue > 0 ? (catSales / totalRevenue) * 100 : 0;
                      const isSelected = filters.selectedCategory === cat;

                      return (
                        <div
                          key={cat}
                          onClick={() =>
                            setFilters((p) => ({
                              ...p,
                              selectedCategory: isSelected ? '' : cat,
                            }))
                          }
                          className={`p-2.5 rounded-lg border transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-blue-50 border-blue-400 font-semibold'
                              : 'bg-slate-50/60 border-slate-200/70 hover:bg-slate-100 hover:border-slate-300'
                          }`}
                        >
                          <div className="flex items-center justify-between text-xs mb-1">
                            <span className="font-bold text-slate-800">{cat}</span>
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-slate-900 tabular-numbers">
                                {formatCurrency(catSales, currency)}
                              </span>
                              <span className="text-[11px] text-slate-500 font-mono">
                                ({pct.toFixed(1)}%)
                              </span>
                            </div>
                          </div>
                          <div className="w-full bg-slate-200 rounded-full h-1.5 overflow-hidden">
                            <div
                              className="bg-indigo-600 h-full rounded-full transition-all duration-300"
                              style={{ width: `${Math.max(4, pct)}%` }}
                            />
                          </div>
                          <div className="flex items-center justify-between text-[10px] text-slate-400 mt-1">
                            <span>{catItems.length} فواتير مسجلة</span>
                            <span>{formatNumber(catQty)} عبوة مباعة</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-400 pt-3 border-t border-slate-100 mt-4">
                  <span>المقياس: SUM(Total Sales) مجمعة حسب Category</span>
                  <span>تصفية فورية عند النقر</span>
                </div>
              </div>
            </div>

            {/* 4. Table 1: Sales by Customer */}
            <CustomerSalesTable
              customers={customerSummaries}
              currency={currency}
              selectedCustomer={filters.selectedCustomer}
              onSelectCustomer={(c) =>
                setFilters((prev) => ({ ...prev, selectedCustomer: c }))
              }
            />

            {/* 5. Table 2: Sales by Item & Quantity */}
            <ItemSalesTable
              items={itemSummaries}
              currency={currency}
              selectedItem={filters.selectedItem}
              onSelectItem={(item) =>
                setFilters((prev) => ({ ...prev, selectedItem: item }))
              }
            />
          </div>
        )}

        {/* ================= TAB 2: CUSTOMERS TAB ================= */}
        {activeTab === 'customers' && (
          <div className="space-y-6">
            <TopCustomersChart
              customers={customerSummaries}
              currency={currency}
              selectedCustomer={filters.selectedCustomer}
              onSelectCustomer={(c) =>
                setFilters((prev) => ({ ...prev, selectedCustomer: c }))
              }
            />

            <CustomerSalesTable
              customers={customerSummaries}
              currency={currency}
              selectedCustomer={filters.selectedCustomer}
              onSelectCustomer={(c) =>
                setFilters((prev) => ({ ...prev, selectedCustomer: c }))
              }
            />
          </div>
        )}

        {/* ================= TAB 3: ITEMS TAB ================= */}
        {activeTab === 'items' && (
          <div className="space-y-6">
            <ItemQuantityDonut
              items={itemSummaries}
              currency={currency}
              selectedItem={filters.selectedItem}
              onSelectItem={(item) =>
                setFilters((prev) => ({ ...prev, selectedItem: item }))
              }
            />

            <ItemSalesTable
              items={itemSummaries}
              currency={currency}
              selectedItem={filters.selectedItem}
              onSelectItem={(item) =>
                setFilters((prev) => ({ ...prev, selectedItem: item }))
              }
            />
          </div>
        )}

        {/* ================= TAB 4: DATA SOURCE ================= */}
        {activeTab === 'dataSource' && (
          <DataSourceManager
            data={salesData}
            setData={setSalesData}
            onOpenAddModal={() => setIsAddModalOpen(true)}
            onOpenPriceModal={() => setIsPriceModalOpen(true)}
            onViewInvoice={(record) => {
              setSelectedInvoiceRecord(record);
              setIsInvoiceModalOpen(true);
            }}
            currency={currency}
          />
        )}

        {/* ================= TAB 5: LOOKER STUDIO GUIDE ================= */}
        {activeTab === 'lookerGuide' && <LookerStudioGuide />}
      </main>

      {/* Modal for adding a new sale entry */}
      <AddSaleModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onAdd={handleAddSale}
        catalog={catalog}
        existingCustomers={customersList}
        existingCategories={categoriesList}
        currency={currency}
      />

      {/* Modal for Price Management & Customization */}
      <PriceManagerModal
        isOpen={isPriceModalOpen}
        onClose={() => setIsPriceModalOpen(false)}
        catalog={catalog}
        onSaveCatalog={handleSaveCatalog}
        currency={currency}
      />

      {/* Modal for APK Build and GitHub Actions */}
      <ApkBuildModal
        isOpen={isApkModalOpen}
        onClose={() => setIsApkModalOpen(false)}
      />

      {/* Modal for PDF Invoice Generation & Print */}
      <InvoicePdfModal
        isOpen={isInvoiceModalOpen}
        onClose={() => setIsInvoiceModalOpen(false)}
        record={selectedInvoiceRecord}
        allRecords={salesData}
        onSelectRecord={setSelectedInvoiceRecord}
        currency={currency}
      />

      {/* Clean Footer */}
      <footer className="mt-auto border-t border-slate-200 bg-white py-6 text-xs text-slate-500 no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-800">{APP_NAME}</span>
            <span aria-hidden="true">·</span>
            <span>المندوب: {DEFAULT_SALES_REP}</span>
            <span aria-hidden="true">·</span>
            <span>{SUPPLIER_LINE} Price List</span>
          </div>
          <div className="flex items-center gap-4 text-[11px] text-slate-400">
            <span>متوافق مع Google Looker Studio و Excel</span>
            <span aria-hidden="true">·</span>
            <span>قائمة أسعار معتمدة</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
