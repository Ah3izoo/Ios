export interface ProductItem {
  id: string;
  productName: string;
  genericName: string;
  category: string;
  defaultPrice: number; // Official price
  currentPrice: number; // Editable price
  boxCrt?: number; // Box per carton
}

export interface SalesRecord {
  id: string;
  orderId: string;
  date: string; // YYYY-MM-DD
  customerName: string;
  customerSegment?: 'مستشفيات' | 'سلاسل صيدليات' | 'صيدليات مجتمعية' | 'مراكز طبية' | 'شركات كبرى' | 'شركات ناشئة';
  itemName: string;
  genericName?: string;
  category: string;
  quantity: number;
  unitPrice: number;
  totalSales: number; // quantity * unitPrice
  salesRep: string; // e.g. "مصطفى محمد"
  boxCrt?: number;
  notes?: string;
}

export interface FilterState {
  dateRange: 'all' | '7days' | '30days' | '90days' | 'thisMonth' | 'lastMonth' | 'custom';
  startDate: string;
  endDate: string;
  selectedCustomer: string;
  selectedCategory: string;
  selectedItem: string;
  selectedSalesRep: string;
  searchQuery: string;
}

export interface CustomerSummary {
  customerName: string;
  segment?: string;
  totalSales: number;
  totalQuantity: number;
  orderCount: number;
  avgOrderValue: number;
  percentageOfTotal: number;
}

export interface ItemSummary {
  itemName: string;
  category: string;
  totalQuantity: number;
  avgUnitPrice: number;
  totalSales: number;
  percentageOfTotal: number;
}

export interface CategorySummary {
  category: string;
  totalSales: number;
  totalQuantity: number;
  percentage: number;
}

export interface TimeSeriesPoint {
  dateKey: string; // YYYY-MM or YYYY-MM-DD
  label: string;
  sales: number;
  quantity: number;
  orders: number;
}

export type CurrencyCode = 'SDG' | 'SAR' | 'USD' | 'AED' | 'EGP' | 'EUR';

export interface CurrencyConfig {
  code: CurrencyCode;
  symbol: string;
  nameAr: string;
  rateFromSAR: number;
}
