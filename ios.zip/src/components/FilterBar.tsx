import React from 'react';
import { FilterState } from '../types';

interface FilterBarProps {
  filters: FilterState;
  setFilters: React.Dispatch<React.SetStateAction<FilterState>>;
  customersList: string[];
  categoriesList: string[];
  itemsList: string[];
  salesRepsList: string[];
  totalFiltered: number;
  totalRecords: number;
  onReset: () => void;
  onExportCSV: () => void;
  onPrint: () => void;
}

export const FilterBar: React.FC<FilterBarProps> = ({
  filters,
  setFilters,
  customersList,
  categoriesList,
  itemsList,
  salesRepsList,
  totalFiltered,
  totalRecords,
  onReset,
  onExportCSV,
  onPrint,
}) => {
  const isFiltered =
    filters.dateRange !== 'all' ||
    filters.selectedCustomer !== '' ||
    filters.selectedCategory !== '' ||
    filters.selectedItem !== '' ||
    filters.selectedSalesRep !== '' ||
    filters.searchQuery !== '';

  return (
    <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs p-4 mb-6">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        {/* Left Side: Filter Controls */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 flex-1">
          {/* 1. Date Range Filter */}
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">
              النطاق الزمني (Date Range)
            </label>
            <select
              value={filters.dateRange}
              onChange={(e) =>
                setFilters((prev) => ({
                  ...prev,
                  dateRange: e.target.value as FilterState['dateRange'],
                }))
              }
              className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2 text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all cursor-pointer font-medium"
            >
              <option value="all">جميع الفترات (All Time)</option>
              <option value="7days">آخر 7 أيام (Last 7 Days)</option>
              <option value="30days">آخر 30 يوماً (Last 30 Days)</option>
              <option value="90days">آخر 90 يوماً (Last Quarter)</option>
              <option value="thisMonth">هذا الشهر (This Month)</option>
              <option value="lastMonth">الشهر الماضي (Last Month)</option>
              <option value="custom">نطاق مخصص (Custom)...</option>
            </select>
          </div>

          {/* 2. Sales Rep Dropdown */}
          <div>
            <label className="block text-xs font-semibold text-blue-700 mb-1">
              المندوب (Sales Rep)
            </label>
            <select
              value={filters.selectedSalesRep}
              onChange={(e) =>
                setFilters((prev) => ({ ...prev, selectedSalesRep: e.target.value }))
              }
              className="w-full text-xs bg-blue-50/60 border border-blue-200 font-bold rounded-lg px-2.5 py-2 text-blue-950 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 cursor-pointer truncate"
            >
              <option value="">جميع المناديب ({salesRepsList.length})</option>
              {salesRepsList.map((rep) => (
                <option key={rep} value={rep}>
                  {rep}
                </option>
              ))}
            </select>
          </div>

          {/* 3. Customer Dropdown */}
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">
              العميل (Customer)
            </label>
            <select
              value={filters.selectedCustomer}
              onChange={(e) =>
                setFilters((prev) => ({ ...prev, selectedCustomer: e.target.value }))
              }
              className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2 text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all cursor-pointer font-medium truncate"
            >
              <option value="">جميع العملاء ({customersList.length})</option>
              {customersList.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          {/* 4. Category Dropdown */}
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">
              الفئة (Category)
            </label>
            <select
              value={filters.selectedCategory}
              onChange={(e) =>
                setFilters((prev) => ({
                  ...prev,
                  selectedCategory: e.target.value,
                  selectedItem: '',
                }))
              }
              className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2 text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all cursor-pointer font-medium"
            >
              <option value="">جميع الفئات</option>
              {categoriesList.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          {/* 5. Item / Product Dropdown */}
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">
              الصنف / الدواء (Item)
            </label>
            <select
              value={filters.selectedItem}
              onChange={(e) =>
                setFilters((prev) => ({ ...prev, selectedItem: e.target.value }))
              }
              className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2 text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all cursor-pointer font-medium truncate"
            >
              <option value="">جميع الأصناف ({itemsList.length})</option>
              {itemsList.map((itm) => (
                <option key={itm} value={itm}>
                  {itm}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Right Side: Search & Actions */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-end gap-2 shrink-0 pt-2 lg:pt-0 border-t lg:border-t-0 border-slate-100">
          {/* Custom Date Pickers if 'custom' selected */}
          {filters.dateRange === 'custom' && (
            <div className="flex items-center gap-2">
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">من</label>
                <input
                  type="date"
                  value={filters.startDate}
                  onChange={(e) => setFilters((p) => ({ ...p, startDate: e.target.value }))}
                  className="text-xs bg-slate-50 border border-slate-300 rounded-lg px-2 py-1.5 focus:bg-white"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">إلى</label>
                <input
                  type="date"
                  value={filters.endDate}
                  onChange={(e) => setFilters((p) => ({ ...p, endDate: e.target.value }))}
                  className="text-xs bg-slate-50 border border-slate-300 rounded-lg px-2 py-1.5 focus:bg-white"
                />
              </div>
            </div>
          )}

          {/* Search input */}
          <div className="w-full sm:w-48">
            <label className="block text-xs font-semibold text-slate-600 mb-1">بحث سريع</label>
            <input
              type="text"
              placeholder="ابحث عن عميل أو صنف..."
              value={filters.searchQuery}
              onChange={(e) => setFilters((p) => ({ ...p, searchQuery: e.target.value }))}
              className="w-full text-xs sm:text-sm bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
            />
          </div>

          {/* Reset button */}
          {isFiltered && (
            <button
              onClick={onReset}
              className="px-3 py-2 text-xs font-semibold text-rose-600 hover:text-rose-700 bg-rose-50 hover:bg-rose-100/70 border border-rose-200 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
              title="إعادة تعيين الفلاتر"
            >
              إلغاء التصفية
            </button>
          )}

          {/* Export & Print */}
          <div className="flex items-center gap-1.5 no-print">
            <button
              onClick={onExportCSV}
              className="px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200/80 border border-slate-200 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
              title="تنزيل جدول البيانات CSV"
            >
              تصدير CSV
            </button>
            <button
              onClick={onPrint}
              className="px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200/80 border border-slate-200 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
              title="طباعة التقرير أو حفظ كـ PDF"
            >
              طباعة / PDF
            </button>
          </div>
        </div>
      </div>

      {/* Filter status ticker */}
      <div className="flex items-center justify-between text-xs text-slate-500 mt-3 pt-2.5 border-t border-slate-100">
        <div className="flex items-center gap-2">
          <span>نتائج العرض:</span>
          <span className="font-bold text-slate-800 tabular-numbers">
            {totalFiltered} من إجمالي {totalRecords} عملية
          </span>
          {isFiltered && (
            <span className="text-amber-700 bg-amber-50 px-2 py-0.5 rounded text-[11px] font-medium border border-amber-200/60">
              مصفى حالياً
            </span>
          )}
        </div>
        <div className="text-[11px] text-slate-400 hidden sm:block">
          Google Looker Studio Dynamic Filter Engine
        </div>
      </div>
    </div>
  );
};
