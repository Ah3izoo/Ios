import React, { useState } from 'react';
import { CurrencyCode, ItemSummary } from '../types';
import { formatCurrency, formatNumber, formatPercent } from '../utils/formatters';

interface ItemSalesTableProps {
  items: ItemSummary[];
  currency: CurrencyCode;
  selectedItem: string;
  onSelectItem: (itemName: string) => void;
}

type SortField = 'itemName' | 'category' | 'totalQuantity' | 'avgUnitPrice' | 'totalSales' | 'percentageOfTotal';
type SortOrder = 'asc' | 'desc';

export const ItemSalesTable: React.FC<ItemSalesTableProps> = ({
  items,
  currency,
  selectedItem,
  onSelectItem,
}) => {
  const [sortField, setSortField] = useState<SortField>('totalSales');
  const [sortOrder, setSortOrder] = useState<SortOrder>('desc');
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [pageSize, setPageSize] = useState<number>(10);
  const [currentPage, setCurrentPage] = useState<number>(1);

  // Categories list for table filter
  const categories = Array.from(new Set(items.map((it) => it.category)));

  // Filter
  const filtered = items.filter((it) => {
    const matchesSearch =
      it.itemName.toLowerCase().includes(search.toLowerCase()) ||
      it.category.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || it.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  // Sort
  const sorted = [...filtered].sort((a, b) => {
    let comp = 0;
    if (sortField === 'itemName' || sortField === 'category') {
      comp = a[sortField].localeCompare(b[sortField], 'ar');
    } else {
      comp = a[sortField] - b[sortField];
    }
    return sortOrder === 'desc' ? -comp : comp;
  });

  // Pagination
  const totalPages = Math.ceil(sorted.length / pageSize) || 1;
  const paginated = sorted.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'desc' ? 'asc' : 'desc');
    } else {
      setSortField(field);
      setSortOrder('desc');
    }
  };

  const maxSales = items.length > 0 ? Math.max(...items.map((i) => i.totalSales)) : 1;

  return (
    <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs overflow-hidden">
      {/* Table Header Controls */}
      <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-bold text-slate-900">
              جدول 2: ملخص المبيعات حسب الأصناف والكميات (Table 2: Sales by Item & Quantity)
            </h3>
            <span className="text-[10px] font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
              Item & Quantity Dimensions
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            تحليل حركة الأصناف، إجمالي الكميات المباعة، متوسط سعر البيع ونسبة كل منتج من الإيرادات
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          {/* Category Filter */}
          <select
            value={categoryFilter}
            onChange={(e) => {
              setCategoryFilter(e.target.value);
              setCurrentPage(1);
            }}
            className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 focus:bg-white cursor-pointer"
          >
            <option value="all">كل الفئات</option>
            {categories.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>

          {/* Search Box */}
          <input
            type="text"
            placeholder="بحث في الأصناف..."
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setCurrentPage(1);
            }}
            className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 focus:bg-white focus:outline-none focus:ring-1 focus:ring-blue-500 w-full sm:w-40"
          />

          <select
            value={pageSize}
            onChange={(e) => {
              setPageSize(Number(e.target.value));
              setCurrentPage(1);
            }}
            className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-2 py-1.5 focus:bg-white cursor-pointer"
          >
            <option value={5}>5 صفوف</option>
            <option value={10}>10 صفوف</option>
            <option value={20}>20 صفاً</option>
          </select>
        </div>
      </div>

      {/* Table Viewport */}
      <div className="overflow-x-auto">
        <table className="w-full text-right text-xs">
          <thead className="bg-slate-50/80 text-slate-600 font-semibold border-b border-slate-200">
            <tr>
              <th className="py-3 px-4 w-12 text-center text-slate-400">#</th>
              <th
                onClick={() => handleSort('itemName')}
                className="py-3 px-4 cursor-pointer hover:bg-slate-100 transition-colors"
              >
                <div className="flex items-center gap-1">
                  <span>اسم الصنف / المنتج (Item Name)</span>
                  {sortField === 'itemName' && (
                    <span>{sortOrder === 'desc' ? '▼' : '▲'}</span>
                  )}
                </div>
              </th>
              <th
                onClick={() => handleSort('category')}
                className="py-3 px-4 cursor-pointer hover:bg-slate-100 transition-colors hidden sm:table-cell"
              >
                <div className="flex items-center gap-1">
                  <span>الفئة (Category)</span>
                  {sortField === 'category' && (
                    <span>{sortOrder === 'desc' ? '▼' : '▲'}</span>
                  )}
                </div>
              </th>
              <th
                onClick={() => handleSort('totalQuantity')}
                className="py-3 px-4 cursor-pointer hover:bg-slate-100 transition-colors text-left"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>الكمية المباعة (SUM Quantity)</span>
                  {sortField === 'totalQuantity' && (
                    <span>{sortOrder === 'desc' ? '▼' : '▲'}</span>
                  )}
                </div>
              </th>
              <th
                onClick={() => handleSort('avgUnitPrice')}
                className="py-3 px-4 cursor-pointer hover:bg-slate-100 transition-colors text-left"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>سعر الوحدة (Unit Price)</span>
                  {sortField === 'avgUnitPrice' && (
                    <span>{sortOrder === 'desc' ? '▼' : '▲'}</span>
                  )}
                </div>
              </th>
              <th
                onClick={() => handleSort('totalSales')}
                className="py-3 px-4 cursor-pointer hover:bg-slate-100 transition-colors text-left"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>إجمالي المبيعات (SUM Total Sales)</span>
                  {sortField === 'totalSales' && (
                    <span>{sortOrder === 'desc' ? '▼' : '▲'}</span>
                  )}
                </div>
              </th>
              <th
                onClick={() => handleSort('percentageOfTotal')}
                className="py-3 px-4 cursor-pointer hover:bg-slate-100 transition-colors text-left w-36"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>نسبة المبيعات (% of Sales)</span>
                  {sortField === 'percentageOfTotal' && (
                    <span>{sortOrder === 'desc' ? '▼' : '▲'}</span>
                  )}
                </div>
              </th>
              <th className="py-3 px-4 text-center w-20">الإجراء</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {paginated.length === 0 ? (
              <tr>
                <td colSpan={8} className="py-8 text-center text-slate-400">
                  لا توجد نتائج مطابقة لبحث الأصناف
                </td>
              </tr>
            ) : (
              paginated.map((it, idx) => {
                const globalIndex = (currentPage - 1) * pageSize + idx + 1;
                const isSelected = selectedItem === it.itemName;
                const barWidth = Math.max(3, (it.totalSales / maxSales) * 100);

                return (
                  <tr
                    key={it.itemName}
                    className={`hover:bg-slate-50 transition-colors ${
                      isSelected ? 'bg-emerald-50/60 font-semibold' : ''
                    }`}
                  >
                    <td className="py-3 px-4 text-center text-slate-400 tabular-numbers">
                      {globalIndex}
                    </td>
                    <td className="py-3 px-4 font-bold text-slate-800">
                      <div className="flex items-center gap-2">
                        <span>{it.itemName}</span>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-slate-600 hidden sm:table-cell">
                      <span>{it.category}</span>
                    </td>
                    <td className="py-3 px-4 text-left font-bold text-slate-900 tabular-numbers">
                      {formatNumber(it.totalQuantity)}{' '}
                      <span className="text-[10px] font-normal text-slate-400">وحدة</span>
                    </td>
                    <td className="py-3 px-4 text-left text-slate-700 tabular-numbers">
                      {formatCurrency(it.avgUnitPrice, currency)}
                    </td>
                    <td className="py-3 px-4 text-left font-bold text-slate-900 tabular-numbers">
                      {formatCurrency(it.totalSales, currency)}
                    </td>
                    <td className="py-3 px-4 text-left">
                      <div className="flex items-center justify-end gap-2">
                        <div className="w-16 bg-slate-100 rounded-full h-1.5 overflow-hidden">
                          <div
                            className="bg-emerald-600 h-full rounded-full"
                            style={{ width: `${barWidth}%` }}
                          />
                        </div>
                        <span className="text-[11px] font-semibold text-slate-600 tabular-numbers w-11 text-left">
                          {formatPercent(it.percentageOfTotal)}
                        </span>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <button
                        onClick={() =>
                          onSelectItem(isSelected ? '' : it.itemName)
                        }
                        className={`text-[11px] px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
                          isSelected
                            ? 'bg-emerald-600 text-white font-bold'
                            : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                        }`}
                        title="تصفية التقرير وفق هذا الصنف"
                      >
                        {isSelected ? 'إلغاء' : 'تصفية'}
                      </button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Footer */}
      <div className="p-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 bg-slate-50/50">
        <div>
          إجمالي الأصناف: <span className="font-bold text-slate-800">{sorted.length}</span>
        </div>
        <div className="flex items-center gap-2">
          <button
            disabled={currentPage <= 1}
            onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
            className="px-2.5 py-1 bg-white border border-slate-200 rounded disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer hover:bg-slate-50"
          >
            السابق
          </button>
          <span className="tabular-numbers">
            صفحة {currentPage} من {totalPages}
          </span>
          <button
            disabled={currentPage >= totalPages}
            onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
            className="px-2.5 py-1 bg-white border border-slate-200 rounded disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer hover:bg-slate-50"
          >
            التالي
          </button>
        </div>
      </div>
    </div>
  );
};
