import React, { useState } from 'react';
import { ProductItem, CurrencyCode } from '../types';
import { formatNumber } from '../utils/formatters';
import { SUPPLIER_LINE } from '../data/productCatalog';

interface PriceManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  catalog: ProductItem[];
  onSaveCatalog: (updatedCatalog: ProductItem[], applyToExistingSales: boolean) => void;
  currency: CurrencyCode;
}

export const PriceManagerModal: React.FC<PriceManagerModalProps> = ({
  isOpen,
  onClose,
  catalog,
  onSaveCatalog,
  currency,
}) => {
  const [localCatalog, setLocalCatalog] = useState<ProductItem[]>(catalog);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [percentAdjust, setPercentAdjust] = useState<number>(0);
  const [applyToExisting, setApplyToExisting] = useState(false);
  const [savedToast, setSavedToast] = useState(false);

  // Sync if prop changes
  React.useEffect(() => {
    setLocalCatalog(catalog);
  }, [catalog]);

  if (!isOpen) return null;

  const categories = Array.from(new Set(catalog.map((i) => i.category)));

  const handlePriceChange = (id: string, newPrice: number) => {
    setLocalCatalog((prev) =>
      prev.map((item) => (item.id === id ? { ...item, currentPrice: Math.max(0, newPrice) } : item))
    );
  };

  const handleApplyPercentage = (pct: number) => {
    if (pct === 0) return;
    setLocalCatalog((prev) =>
      prev.map((item) => {
        const adjusted = Math.round(item.currentPrice * (1 + pct / 100));
        return { ...item, currentPrice: Math.max(0, adjusted) };
      })
    );
    setPercentAdjust(0);
  };

  const handleResetToOfficial = () => {
    setLocalCatalog((prev) =>
      prev.map((item) => ({ ...item, currentPrice: item.defaultPrice }))
    );
  };

  const handleSave = () => {
    onSaveCatalog(localCatalog, applyToExisting);
    setSavedToast(true);
    setTimeout(() => {
      setSavedToast(false);
      onClose();
    }, 1200);
  };

  const filtered = localCatalog.filter((item) => {
    const matchesSearch =
      item.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.genericName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || item.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] shadow-2xl border border-slate-200 flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-600" />
              <h2 className="text-base font-bold text-slate-900">
                إدارة وتعديل أسعار الأصناف (Price Management & Master Catalog)
              </h2>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              خط إنتاج {SUPPLIER_LINE} · قائمة الأسعار المعتمدة
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 text-lg font-bold p-1 cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Quick Batch Tools Bar */}
        <div className="p-4 bg-slate-100/70 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-semibold text-slate-700">تعديل جماعي:</span>
            <div className="flex items-center gap-1 bg-white border border-slate-300 rounded-lg p-1">
              <input
                type="number"
                placeholder="النسبة %"
                value={percentAdjust || ''}
                onChange={(e) => setPercentAdjust(parseFloat(e.target.value) || 0)}
                className="w-16 px-1.5 py-0.5 text-xs text-center border-none focus:outline-none tabular-numbers"
              />
              <button
                type="button"
                onClick={() => handleApplyPercentage(percentAdjust)}
                className="px-2 py-1 bg-blue-600 text-white rounded font-medium hover:bg-blue-700 cursor-pointer"
              >
                تطبيق %
              </button>
            </div>
            <button
              type="button"
              onClick={() => handleApplyPercentage(5)}
              className="px-2.5 py-1.5 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg font-medium text-slate-700 cursor-pointer"
            >
              +5% زيادة
            </button>
            <button
              type="button"
              onClick={() => handleApplyPercentage(-5)}
              className="px-2.5 py-1.5 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg font-medium text-slate-700 cursor-pointer"
            >
              -5% خصم
            </button>
            <button
              type="button"
              onClick={handleResetToOfficial}
              className="px-2.5 py-1.5 bg-white border border-amber-300 text-amber-800 hover:bg-amber-50 rounded-lg font-medium cursor-pointer"
            >
              استعادة التسعيرة الأصلية
            </button>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="text"
              placeholder="بحث في الأصناف أو المواد..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="text-xs bg-white border border-slate-300 rounded-lg px-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-blue-500 w-44"
            />
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="text-xs bg-white border border-slate-300 rounded-lg px-2 py-1.5 focus:outline-none cursor-pointer"
            >
              <option value="all">كل الفئات ({catalog.length})</option>
              {categories.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Scrollable Products Table */}
        <div className="flex-1 overflow-y-auto p-4">
          <table className="w-full text-right text-xs">
            <thead className="bg-slate-50 text-slate-600 font-semibold sticky top-0 border-b border-slate-200 z-10">
              <tr>
                <th className="py-2.5 px-3 w-10 text-center text-slate-400">#</th>
                <th className="py-2.5 px-3">اسم الصنف (Product Name)</th>
                <th className="py-2.5 px-3">الاسم العلمي (Generic Name)</th>
                <th className="py-2.5 px-3">الفئة (Category)</th>
                <th className="py-2.5 px-3 text-left">السعر الرسمي (W.Price)</th>
                <th className="py-2.5 px-3 text-left w-36">السعر المعتمد الجديد</th>
                <th className="py-2.5 px-3 text-center w-24">الحالة</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((item, idx) => {
                const isModified = item.currentPrice !== item.defaultPrice;
                const diffPct =
                  item.defaultPrice > 0
                    ? ((item.currentPrice - item.defaultPrice) / item.defaultPrice) * 100
                    : 0;

                return (
                  <tr key={item.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-2.5 px-3 text-center text-slate-400 tabular-numbers">
                      {idx + 1}
                    </td>
                    <td className="py-2.5 px-3 font-bold text-slate-900">
                      {item.productName}
                    </td>
                    <td className="py-2.5 px-3 text-slate-600 font-mono text-[11px]">
                      {item.genericName}
                    </td>
                    <td className="py-2.5 px-3 text-slate-500">
                      {item.category}
                    </td>
                    <td className="py-2.5 px-3 text-left font-mono text-slate-500 tabular-numbers">
                      {formatNumber(item.defaultPrice)}
                    </td>
                    <td className="py-2.5 px-3 text-left">
                      <div className="flex items-center gap-1 justify-end">
                        <input
                          type="number"
                          min="0"
                          step="any"
                          value={item.currentPrice}
                          onChange={(e) =>
                            handlePriceChange(item.id, parseFloat(e.target.value) || 0)
                          }
                          className={`w-28 text-left font-bold text-xs px-2 py-1 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 tabular-numbers ${
                            isModified
                              ? 'bg-amber-50 border-amber-300 text-amber-900 font-extrabold'
                              : 'bg-white border-slate-300 text-slate-800'
                          }`}
                        />
                      </div>
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      {isModified ? (
                        <span
                          className={`inline-block px-1.5 py-0.5 rounded text-[10px] font-bold ${
                            diffPct > 0
                              ? 'bg-emerald-50 text-emerald-700'
                              : 'bg-rose-50 text-rose-700'
                          }`}
                        >
                          {diffPct > 0 ? `+${diffPct.toFixed(1)}%` : `${diffPct.toFixed(1)}%`}
                        </span>
                      ) : (
                        <span className="text-slate-400 text-[10px]">رسمي</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
          <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
            <input
              type="checkbox"
              checked={applyToExisting}
              onChange={(e) => setApplyToExisting(e.target.checked)}
              className="rounded text-blue-600 focus:ring-blue-500 cursor-pointer"
            />
            <span>تحديث الأسعار في سجلات وفواتير المبيعات السابقة أيضاً (Recalculate Existing Sales)</span>
          </label>

          <div className="flex items-center gap-2">
            {savedToast && (
              <span className="text-xs text-emerald-700 font-bold bg-emerald-50 px-2 py-1 rounded">
                ✓ تم حفظ وتحديث الأسعار بنجاح!
              </span>
            )}
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-200/80 rounded-lg transition-colors cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm transition-colors cursor-pointer"
            >
              حفظ وتطبيق الأسعار الجديدة
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
