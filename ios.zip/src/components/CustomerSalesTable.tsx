import React, { useState } from 'react';
import { CurrencyCode, CustomerSummary } from '../types';
import { formatCurrency, formatNumber, formatPercent } from '../utils/formatters';

interface CustomerSalesTableProps {
  customers: CustomerSummary[];
  currency: CurrencyCode;
  selectedCustomer: string;
  onSelectCustomer: (name: string) => void;
}

type SortField = 'customerName' | 'totalSales' | 'totalQuantity' | 'orderCount' | 'avgOrderValue';
type SortOrder = 'asc' | 'desc';

export const CustomerSalesTable: React.FC<CustomerSalesTableProps> = ({
  customers,
  currency,
  selectedCustomer,
  onSelectCustomer,
}) => {
  const [sortField, setSortField] = useState<SortField>('totalSales');
  const [sortOrder, setSortOrder] = useState<SortOrder>('desc');
  const [search, setSearch] = useState('');
  const [pageSize, setPageSize] = useState<number>(10);
  const [currentPage, setCurrentPage] = useState<number>(1);

  // Filter
  const filtered = customers.filter((c) =>
    c.customerName.toLowerCase().includes(search.toLowerCase())
  );

  // Sort
  const sorted = [...filtered].sort((a, b) => {
    let comparison = 0;
    if (sortField === 'customerName') {
      comparison = a.customerName.localeCompare(b.customerName, 'ar');
    } else {
      comparison = a[sortField] - b[sortField];
    }
    return sortOrder === 'desc' ? -comparison : comparison;
  });

  // Pagination
  const totalPages = Math.ceil(sorted.length / pageSize) || 1;
  const paginated = sorted.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'desc' ? 'asc' : 'desc');
    } else {
      setSortField(field);
      setSortOrder('desc');
    }
  };

  const maxSales = customers.length > 0 ? Math.max(...customers.map((c) => c.totalSales)) : 1;

  return (
    <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs overflow-hidden">
      {/* Table Header Controls */}
      <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-bold text-slate-900">
              جدول 1: ملخص المبيعات حسب العملاء (Table 1: Sales by Customer)
            </h3>
            <span className="text-[10px] font-mono text-blue-600 bg-blue-50 px-2 py-0.5 rounded">
              Customer Dimension
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            تحليل تفصيلي لأداء العملاء، إجمالي القيمة، عدد العمليات ومتوسط الفاتورة
          </p>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <input
            type="text"
            placeholder="بحث في أسماء العملاء..."
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setCurrentPage(1);
            }}
            className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 focus:bg-white focus:outline-none focus:ring-1 focus:ring-blue-500 w-full sm:w-44"
          />

          <select
            value={pageSize}
            onChange={(e) => {
              setPageSize(Number(e.target.value));
              setCurrentPage(1);
            }}
            className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-2 py-1.5 focus:bg-white cursor-pointer"
          >
            <option value={5}>5 صفوف</option>
            <option value={10}>10 صفوف</option>
            <option value={25}>25 صفاً</option>
          </select>
        </div>
      </div>

      {/* Table Viewport */}
      <div className="overflow-x-auto">
        <table className="w-full text-right text-xs">
          <thead className="bg-slate-50/80 text-slate-600 font-semibold border-b border-slate-200">
            <tr>
              <th className="py-3 px-4 w-12 text-center text-slate-400">#</th>
              <th
                onClick={() => handleSort('customerName')}
                className="py-3 px-4 cursor-pointer hover:bg-slate-100 transition-colors"
              >
                <div className="flex items-center gap-1">
                  <span>اسم العميل (Customer Name)</span>
                  {sortField === 'customerName' && (
                    <span>{sortOrder === 'desc' ? '▼' : '▲'}</span>
                  )}
                </div>
              </th>
              <th
                onClick={() => handleSort('totalSales')}
                className="py-3 px-4 cursor-pointer hover:bg-slate-100 transition-colors text-left"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>إجمالي المبيعات (SUM Sales)</span>
                  {sortField === 'totalSales' && (
                    <span>{sortOrder === 'desc' ? '▼' : '▲'}</span>
                  )}
                </div>
              </th>
              <th className="py-3 px-4 w-32 hidden md:table-cell text-center">
                نسبة المساهمة
              </th>
              <th
                onClick={() => handleSort('totalQuantity')}
                className="py-3 px-4 cursor-pointer hover:bg-slate-100 transition-colors text-left"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>الكمية المباعة (SUM Quantity)</span>
                  {sortField === 'totalQuantity' && (
                    <span>{sortOrder === 'desc' ? '▼' : '▲'}</span>
                  )}
                </div>
              </th>
              <th
                onClick={() => handleSort('orderCount')}
                className="py-3 px-4 cursor-pointer hover:bg-slate-100 transition-colors text-left"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>عدد الفواتير (COUNT Orders)</span>
                  {sortField === 'orderCount' && (
                    <span>{sortOrder === 'desc' ? '▼' : '▲'}</span>
                  )}
                </div>
              </th>
              <th
                onClick={() => handleSort('avgOrderValue')}
                className="py-3 px-4 cursor-pointer hover:bg-slate-100 transition-colors text-left"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>متوسط الفاتورة (AOV)</span>
                  {sortField === 'avgOrderValue' && (
                    <span>{sortOrder === 'desc' ? '▼' : '▲'}</span>
                  )}
                </div>
              </th>
              <th className="py-3 px-4 text-center w-20">الإجراء</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {paginated.length === 0 ? (
              <tr>
                <td colSpan={8} className="py-8 text-center text-slate-400">
                  لا توجد نتائج مطابقة لبحث العملاء
                </td>
              </tr>
            ) : (
              paginated.map((c, idx) => {
                const globalIndex = (currentPage - 1) * pageSize + idx + 1;
                const isSelected = selectedCustomer === c.customerName;
                const barWidth = Math.max(4, (c.totalSales / maxSales) * 100);

                return (
                  <tr
                    key={c.customerName}
                    className={`hover:bg-slate-50 transition-colors ${
                      isSelected ? 'bg-blue-50/70 font-semibold' : ''
                    }`}
                  >
                    <td className="py-3 px-4 text-center text-slate-400 tabular-numbers">
                      {globalIndex}
                    </td>
                    <td className="py-3 px-4 font-bold text-slate-800">
                      <div className="flex items-center gap-2">
                        <span className="truncate">{c.customerName}</span>
                        {c.segment && (
                          <span className="text-[10px] text-slate-500 font-normal">
                            · {c.segment}
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-left font-bold text-slate-900 tabular-numbers">
                      {formatCurrency(c.totalSales, currency)}
                    </td>
                    <td className="py-3 px-4 hidden md:table-cell">
                      <div className="flex items-center gap-2">
                        <div className="flex-1 bg-slate-100 rounded-full h-1.5 overflow-hidden">
                          <div
                            className="bg-blue-600 h-full rounded-full"
                            style={{ width: `${barWidth}%` }}
                          />
                        </div>
                        <span className="text-[11px] text-slate-500 tabular-numbers w-10 text-left">
                          {formatPercent(c.percentageOfTotal)}
                        </span>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-left tabular-numbers text-slate-700">
                      {formatNumber(c.totalQuantity)}{' '}
                      <span className="text-[10px] text-slate-400">وحدة</span>
                    </td>
                    <td className="py-3 px-4 text-left tabular-numbers text-slate-700">
                      {formatNumber(c.orderCount)}{' '}
                      <span className="text-[10px] text-slate-400">طلب</span>
                    </td>
                    <td className="py-3 px-4 text-left font-medium text-slate-800 tabular-numbers">
                      {formatCurrency(c.avgOrderValue, currency)}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <button
                        onClick={() =>
                          onSelectCustomer(isSelected ? '' : c.customerName)
                        }
                        className={`text-[11px] px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
                          isSelected
                            ? 'bg-blue-600 text-white font-bold'
                            : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                        }`}
                        title="تصفية التقرير وفق هذا العميل"
                      >
                        {isSelected ? 'إلغاء' : 'تصفية'}
                      </button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Footer */}
      <div className="p-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 bg-slate-50/50">
        <div>
          إجمالي العملاء: <span className="font-bold text-slate-800">{sorted.length}</span>
        </div>
        <div className="flex items-center gap-2">
          <button
            disabled={currentPage <= 1}
            onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
            className="px-2.5 py-1 bg-white border border-slate-200 rounded disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer hover:bg-slate-50"
          >
            السابق
          </button>
          <span className="tabular-numbers">
            صفحة {currentPage} من {totalPages}
          </span>
          <button
            disabled={currentPage >= totalPages}
            onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
            className="px-2.5 py-1 bg-white border border-slate-200 rounded disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer hover:bg-slate-50"
          >
            التالي
          </button>
        </div>
      </div>
    </div>
  );
};
