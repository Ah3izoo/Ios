import React from 'react';
import { CurrencyCode } from '../types';
import { formatCurrency, formatNumber } from '../utils/formatters';

interface ScorecardsProps {
  totalRevenue: number;
  totalQuantity: number;
  distinctCustomers: number;
  orderCount: number;
  averageOrderValue: number;
  currency: CurrencyCode;
}

export const Scorecards: React.FC<ScorecardsProps> = ({
  totalRevenue,
  totalQuantity,
  distinctCustomers,
  orderCount,
  averageOrderValue,
  currency,
}) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5 mb-6">
      {/* 1. إجمالي المبيعات */}
      <div className="bg-white rounded-xl border border-slate-200/90 p-4 shadow-xs hover:border-blue-300 transition-colors">
        <div className="flex items-center justify-between text-xs text-slate-500 mb-1.5 font-medium">
          <span>إجمالي المبيعات</span>
          <span className="text-[10px] font-mono text-slate-400">SUM(Total Sales)</span>
        </div>
        <div className="text-xl sm:text-2xl font-bold text-slate-900 tabular-numbers tracking-tight">
          {formatCurrency(totalRevenue, currency)}
        </div>
        <div className="mt-2 text-[11px] text-slate-500 flex items-center justify-between">
          <span>صافي الإيرادات المسجلة</span>
          <span className="text-emerald-700 font-semibold bg-emerald-50 px-1.5 py-0.5 rounded text-[10px]">
            المؤشر المالي الأساسي
          </span>
        </div>
      </div>

      {/* 2. إجمالي الكميات المباعة */}
      <div className="bg-white rounded-xl border border-slate-200/90 p-4 shadow-xs hover:border-blue-300 transition-colors">
        <div className="flex items-center justify-between text-xs text-slate-500 mb-1.5 font-medium">
          <span>إجمالي الكميات المباعة</span>
          <span className="text-[10px] font-mono text-slate-400">SUM(Quantity)</span>
        </div>
        <div className="text-xl sm:text-2xl font-bold text-slate-900 tabular-numbers tracking-tight">
          {formatNumber(totalQuantity)}{' '}
          <span className="text-xs font-normal text-slate-500">وحدة</span>
        </div>
        <div className="mt-2 text-[11px] text-slate-500 flex items-center justify-between">
          <span>حجم البضائع والوحدات</span>
          <span className="text-blue-700 font-semibold bg-blue-50 px-1.5 py-0.5 rounded text-[10px]">
            معدل التدفق
          </span>
        </div>
      </div>

      {/* 3. إجمالي عدد العملاء */}
      <div className="bg-white rounded-xl border border-slate-200/90 p-4 shadow-xs hover:border-blue-300 transition-colors">
        <div className="flex items-center justify-between text-xs text-slate-500 mb-1.5 font-medium">
          <span>إجمالي العملاء النشطين</span>
          <span className="text-[10px] font-mono text-slate-400">COUNT_DISTINCT</span>
        </div>
        <div className="text-xl sm:text-2xl font-bold text-slate-900 tabular-numbers tracking-tight">
          {formatNumber(distinctCustomers)}{' '}
          <span className="text-xs font-normal text-slate-500">عميل</span>
        </div>
        <div className="mt-2 text-[11px] text-slate-500 flex items-center justify-between">
          <span>قاعدة العملاء الفريدة</span>
          <span className="text-slate-600 font-medium text-[10px]">
            {distinctCustomers > 0 ? (orderCount / distinctCustomers).toFixed(1) : 0} طلب/عميل
          </span>
        </div>
      </div>

      {/* 4. عدد الطلبات / الفواتير */}
      <div className="bg-white rounded-xl border border-slate-200/90 p-4 shadow-xs hover:border-blue-300 transition-colors">
        <div className="flex items-center justify-between text-xs text-slate-500 mb-1.5 font-medium">
          <span>عدد الفواتير / الطلبات</span>
          <span className="text-[10px] font-mono text-slate-400">RECORD_COUNT</span>
        </div>
        <div className="text-xl sm:text-2xl font-bold text-slate-900 tabular-numbers tracking-tight">
          {formatNumber(orderCount)}{' '}
          <span className="text-xs font-normal text-slate-500">فاتورة</span>
        </div>
        <div className="mt-2 text-[11px] text-slate-500 flex items-center justify-between">
          <span>العمليات المنجزة</span>
          <span className="text-indigo-700 font-semibold bg-indigo-50 px-1.5 py-0.5 rounded text-[10px]">
            100% مكتملة
          </span>
        </div>
      </div>

      {/* 5. متوسط الفاتورة */}
      <div className="bg-white rounded-xl border border-slate-200/90 p-4 shadow-xs hover:border-blue-300 transition-colors">
        <div className="flex items-center justify-between text-xs text-slate-500 mb-1.5 font-medium">
          <span>متوسط قيمة الفاتورة (AOV)</span>
          <span className="text-[10px] font-mono text-slate-400">SUM(Sales)/COUNT</span>
        </div>
        <div className="text-xl sm:text-2xl font-bold text-slate-900 tabular-numbers tracking-tight">
          {formatCurrency(averageOrderValue, currency)}
        </div>
        <div className="mt-2 text-[11px] text-slate-500 flex items-center justify-between">
          <span>معدل الصرف للطلب الواحد</span>
          <span className="text-purple-700 font-semibold bg-purple-50 px-1.5 py-0.5 rounded text-[10px]">
            سلة المشتريات
          </span>
        </div>
      </div>
    </div>
  );
};
