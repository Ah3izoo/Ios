import React, { useState } from 'react';

interface ApkBuildModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ApkBuildModal: React.FC<ApkBuildModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'ios' | 'android'>('ios');
  const [copied, setCopied] = useState<string | null>(null);

  if (!isOpen) return null;

  const currentUrl = typeof window !== 'undefined' ? window.location.href : '';

  const copyText = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(null), 2500);
  };

  const gitCommands = `git init
git add .
git commit -m "Build Android APK via GitHub Actions"
git branch -M main
git remote add origin https://github.com/YOUR_USER/YOUR_REPO.git
git push -u origin main`;

  const iosCapacitorCommands = `npm install @capacitor/ios
npx cap add ios
npm run build
npx cap sync ios
npx cap open ios`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] shadow-2xl border border-slate-200 flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-lg shadow-xs text-white ${activeTab === 'ios' ? 'bg-slate-900' : 'bg-emerald-600'}`}>
              {activeTab === 'ios' ? '🍏' : '🤖'}
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                {activeTab === 'ios'
                  ? 'تشغيل وتثبيت التطبيق على الآيفون (iPhone & iOS)'
                  : 'بناء وتحميل تطبيق أندرويد (APK)'}
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                تطبيق مصطفى بترجي مخصص للعمل بكفاءة تامة على هواتف آبل والأنظمة المحمولة
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 text-lg font-bold p-1 cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Platform Selection Tabs */}
        <div className="flex border-b border-slate-200 bg-slate-100/70 p-1.5 gap-1.5">
          <button
            type="button"
            onClick={() => setActiveTab('ios')}
            className={`flex-1 py-2 px-3 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-2 cursor-pointer ${
              activeTab === 'ios'
                ? 'bg-white text-slate-900 shadow-xs border border-slate-200'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
            }`}
          >
            <span>🍏 تطبيق الآيفون (iPhone / Safari PWA)</span>
            <span className="bg-blue-100 text-blue-700 text-[10px] px-1.5 py-0.5 rounded-full font-semibold">
              الموصى به
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('android')}
            className={`flex-1 py-2 px-3 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-2 cursor-pointer ${
              activeTab === 'android'
                ? 'bg-white text-slate-900 shadow-xs border border-slate-200'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
            }`}
          >
            <span>🤖 أندرويد (Android APK)</span>
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4 text-xs text-slate-700 leading-relaxed">
          {/* TAB 1: iOS iPhone */}
          {activeTab === 'ios' && (
            <div className="space-y-4">
              {/* Highlight Box: 10-second Safari install */}
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-xl">
                <div className="flex items-start gap-3">
                  <div className="text-2xl shrink-0">📲</div>
                  <div>
                    <div className="font-bold text-blue-950 text-sm">
                      تثبيت فوري على شاشة الآيفون في 10 ثوانٍ (بدون App Store)
                    </div>
                    <p className="text-blue-800 text-[11px] mt-1 leading-relaxed">
                      يدعم التطبيق تقنية <strong>Apple PWA</strong> بالكامل؛ حيث يعمل كتطبيق مستقل بشاشة كاملة بدون شريط متصفح سفاري ويدعم العمل دون اتصال بالإنترنت وحفظ البيانات على هاتفك.
                    </p>
                  </div>
                </div>
              </div>

              {/* Share link to iPhone button */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 flex flex-col sm:flex-row items-center justify-between gap-3">
                <div>
                  <span className="font-bold text-slate-900 block text-xs">رابط تشغيل التطبيق للآيفون:</span>
                  <span className="text-[11px] text-slate-500 font-mono break-all">{currentUrl}</span>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => copyText(currentUrl, 'url')}
                    className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold text-xs cursor-pointer shadow-xs transition-colors flex items-center gap-1.5"
                  >
                    <span>{copied === 'url' ? '✓ تم النسخ' : '📋 نسخ الرابط'}</span>
                  </button>
                  <a
                    href={`https://wa.me/?text=${encodeURIComponent(`رابط تطبيق مصطفى بترجي للمبيعات والفواتير:\n${currentUrl}`)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-xs cursor-pointer shadow-xs transition-colors flex items-center gap-1"
                  >
                    <span>إرسال عبر واتساب</span>
                  </a>
                </div>
              </div>

              {/* Visual Step-by-Step for iOS */}
              <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/60 space-y-3">
                <span className="font-bold text-slate-900 text-xs block">
                  خطوات إضافة التطبيق لشاشة الآيفون الرئيسية:
                </span>
                
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="bg-white p-3 rounded-lg border border-slate-200 text-center flex flex-col items-center">
                    <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center text-sm mb-2">
                      1
                    </div>
                    <span className="font-bold text-slate-900 mb-1">افتح الرابط بسفاري</span>
                    <span className="text-[11px] text-slate-500">
                      افتح رابط التطبيق عبر متصفح <strong>Safari</strong> على جهاز الآيفون.
                    </span>
                  </div>

                  <div className="bg-white p-3 rounded-lg border border-slate-200 text-center flex flex-col items-center">
                    <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center text-sm mb-2">
                      2
                    </div>
                    <span className="font-bold text-slate-900 mb-1">زر المشاركة (Share)</span>
                    <span className="text-[11px] text-slate-500">
                      اضغط على زر المشاركة <strong>(مربع بسهم للأعلى ⎋)</strong> أسفل شاشة سفاري.
                    </span>
                  </div>

                  <div className="bg-white p-3 rounded-lg border border-slate-200 text-center flex flex-col items-center">
                    <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center text-sm mb-2">
                      3
                    </div>
                    <span className="font-bold text-slate-900 mb-1">إضافة للشاشة الرئيسية</span>
                    <span className="text-[11px] text-slate-500">
                      اختر <strong>«إضافة إلى الشاشة الرئيسية»</strong> ثم اضغط <strong>«إضافة»</strong>.
                    </span>
                  </div>
                </div>

                <div className="text-[11px] text-slate-600 bg-white p-2.5 rounded-lg border border-slate-200">
                  ✨ <strong>النتيجة:</strong> سيظهر تطبيق <strong>«مصطفى بترجي»</strong> كأيقونة تطبيق كامل على شاشة الآيفون، ويفتح في وضع ملء الشاشة بدون شريط المتصفح، مع الاحتفاظ ببيانات الفواتير والأسعار حتى دون اتصال.
                </div>
              </div>

              {/* Developer / Xcode Native iOS Packaging option */}
              <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/60">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-bold text-slate-900 text-xs">
                    خيار المطورين: حزمة مشروع iOS أصلي (Xcode / Capacitor):
                  </span>
                  <button
                    type="button"
                    onClick={() => copyText(iosCapacitorCommands, 'ios-cmd')}
                    className="px-2.5 py-1 bg-white border border-slate-200 hover:bg-slate-100 rounded-md font-semibold text-slate-700 cursor-pointer text-[11px]"
                  >
                    {copied === 'ios-cmd' ? '✓ تم النسخ' : 'نسخ أوامر iOS'}
                  </button>
                </div>
                <pre className="bg-slate-900 text-cyan-300 p-2.5 rounded-lg font-mono text-[11px] overflow-x-auto text-left dir-ltr">
                  {iosCapacitorCommands}
                </pre>
              </div>
            </div>
          )}

          {/* TAB 2: Android APK */}
          {activeTab === 'android' && (
            <div className="space-y-3">
              {/* Status Box */}
              <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between">
                <div>
                  <div className="font-bold text-emerald-900 text-sm">
                    ملف سير العمل مُعد بالكامل في المشروع:
                  </div>
                  <div className="font-mono text-[11px] text-emerald-700 mt-0.5">
                    .github/workflows/build-apk.yml
                  </div>
                </div>
                <span className="text-[11px] font-bold bg-emerald-600 text-white px-2.5 py-1 rounded-md">
                  Capacitor 8 + Java 17
                </span>
              </div>

              <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/60">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-bold text-slate-900 text-xs">
                    1. رفع المشروع إلى GitHub:
                  </span>
                  <button
                    type="button"
                    onClick={() => copyText(gitCommands, 'git')}
                    className="px-2.5 py-1 bg-white border border-slate-200 hover:bg-slate-100 rounded-md font-semibold text-slate-700 cursor-pointer text-[11px]"
                  >
                    {copied === 'git' ? '✓ تم النسخ' : 'نسخ الأوامر'}
                  </button>
                </div>
                <pre className="bg-slate-900 text-emerald-400 p-3 rounded-lg font-mono text-[11px] overflow-x-auto text-left dir-ltr">
                  {gitCommands}
                </pre>
              </div>

              <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/60">
                <span className="font-bold text-slate-900 text-xs block mb-1.5">
                  2. كيف يتم بناء وتحميل الـ APK من GitHub:
                </span>
                <ol className="list-decimal list-inside space-y-1.5 text-slate-600 text-[11px]">
                  <li>
                    بمجرد عمل <code className="font-mono text-blue-600">git push</code>، يدخل سير العمل في GitHub للعمل تلقائياً.
                  </li>
                  <li>
                    اذهب إلى تبويب <strong>Actions</strong> في مستودع GitHub الخاص بك.
                  </li>
                  <li>
                    اضغط على عملية البناء المسماة <strong>Build Android APK</strong>.
                  </li>
                  <li>
                    في أسفل الصفحة تحت قسم <strong>Artifacts</strong>، اضغط على <strong>LookerSalesStudio-Android-APK</strong> لتحميل ملف الـ APK.
                  </li>
                </ol>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <span className="text-[11px] text-slate-500">
            {activeTab === 'ios'
              ? 'متوافق مع جميع أجهزة iPhone و iPad بنظام iOS 14 فما فوق'
              : 'جاهز للبناء كملف APK مستقل للأندرويد'}
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
