import React, { useRef, useState } from 'react';
import { CurrencyCode, SalesRecord } from '../types';
import { copyForGoogleSheets, exportToCSV, parseCSV } from '../utils/csvHelper';
import { formatCurrency, formatNumber } from '../utils/formatters';

interface DataSourceManagerProps {
  data: SalesRecord[];
  setData: React.Dispatch<React.SetStateAction<SalesRecord[]>>;
  onOpenAddModal: () => void;
  onOpenPriceModal: () => void;
  onViewInvoice: (record: SalesRecord) => void;
  currency: CurrencyCode;
}

export const DataSourceManager: React.FC<DataSourceManagerProps> = ({
  data,
  setData,
  onOpenAddModal,
  onOpenPriceModal,
  onViewInvoice,
  currency,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [copySuccess, setCopySuccess] = useState(false);
  const [importNotice, setImportNotice] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  const handleCopySheets = async () => {
    const success = await copyForGoogleSheets(data);
    if (success) {
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 3000);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (text) {
        try {
          const parsed = parseCSV(text);
          if (parsed.length > 0) {
            setData((prev) => [...parsed, ...prev]);
            setImportNotice(`تم استيراد ${parsed.length} صفاً بنجاح ودمجها في مصدر البيانات.`);
          } else {
            setImportNotice('لم يتم العثور على صفوف صالحة. تأكد من ترويسة الأعمدة المطلوبة.');
          }
        } catch (err) {
          setImportNotice('حدث خطأ أثناء قراءة ملف CSV.');
        }
      }
    };
    reader.readAsText(file);
    // reset input
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleDeleteRecord = (id: string) => {
    setData((prev) => prev.filter((r) => r.id !== id));
  };

  const filteredRecords = data.filter(
    (r) =>
      r.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.itemName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (r.salesRep && r.salesRep.toLowerCase().includes(searchTerm.toLowerCase())) ||
      r.orderId.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* 1. Header & Quick Actions Banner */}
      <div className="bg-white rounded-xl border border-slate-200/90 p-5 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              <h2 className="text-base font-bold text-slate-900">
                إدارة مصدر البيانات (Data Source Engine)
              </h2>
              <span className="text-xs text-slate-500 bg-slate-100 px-2 py-0.5 rounded font-mono">
                مصطفى بترجي · المندوب: مصطفى محمد
              </span>
            </div>
            <p className="text-xs text-slate-600 mt-1 max-w-2xl leading-relaxed">
              جدول مبيعات أصناف مصطفى بترجي (Betterjee Pharma) مع خيار تخصيص الأسعار، التصدير لـ Google Sheets، وطباعة الفواتير PDF.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              accept=".csv,.txt,.tsv"
              className="hidden"
            />
            <button
              onClick={() => data.length > 0 && onViewInvoice(data[0])}
              className="px-3 py-2 text-xs font-semibold text-purple-700 bg-purple-50 hover:bg-purple-100 rounded-lg transition-colors cursor-pointer border border-purple-200 flex items-center gap-1"
            >
              <span>طباعة فاتورة PDF 📄</span>
            </button>
            <button
              onClick={onOpenPriceModal}
              className="px-3 py-2 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors cursor-pointer border border-blue-200"
            >
              تعديل أسعار الأصناف
            </button>
            <button
              onClick={() => fileInputRef.current?.click()}
              className="px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer border border-slate-200"
            >
              استيراد CSV
            </button>
            <button
              onClick={handleCopySheets}
              className={`px-3 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer border ${
                copySuccess
                  ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                  : 'bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200'
              }`}
            >
              {copySuccess ? '✓ تم النسخ لـ Sheets' : 'نسخ لـ Google Sheets'}
            </button>
            <button
              onClick={() => exportToCSV(data)}
              className="px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer border border-slate-200"
            >
              تحميل CSV
            </button>
            <button
              onClick={onOpenAddModal}
              className="px-4 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              + إضافة فاتورة
            </button>
          </div>
        </div>

        {importNotice && (
          <div className="mt-4 p-3 bg-blue-50 border border-blue-200 text-blue-800 text-xs rounded-lg flex items-center justify-between">
            <span>{importNotice}</span>
            <button
              onClick={() => setImportNotice(null)}
              className="font-bold hover:text-blue-950 cursor-pointer"
            >
              ✕
            </button>
          </div>
        )}
      </div>

      {/* 2. Schema Blueprint Box */}
      <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
        <h3 className="text-xs font-bold text-slate-800 mb-2 flex items-center justify-between">
          <span>هيكل وتوصيف الأعمدة لمصدر البيانات (Field Typing & Schema)</span>
          <span className="text-[11px] text-slate-500 font-normal">
            مطابق لمواصفات Google Looker Studio
          </span>
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 text-xs">
          <div className="bg-white p-2.5 rounded-lg border border-slate-200/70">
            <span className="text-[10px] text-slate-400 block font-mono">Date</span>
            <span className="font-bold text-slate-850">التاريخ</span>
            <span className="text-[10px] text-blue-600 block mt-0.5 font-medium">نوع: Date (YYYY-MM-DD)</span>
          </div>
          <div className="bg-white p-2.5 rounded-lg border border-slate-200/70">
            <span className="text-[10px] text-slate-400 block font-mono">Customer Name</span>
            <span className="font-bold text-slate-850">اسم العميل</span>
            <span className="text-[10px] text-purple-600 block mt-0.5 font-medium">نوع: Text (بُعد أساسي)</span>
          </div>
          <div className="bg-white p-2.5 rounded-lg border border-slate-200/70">
            <span className="text-[10px] text-slate-400 block font-mono">Item Name</span>
            <span className="font-bold text-slate-850">الصنف / المنتج</span>
            <span className="text-[10px] text-purple-600 block mt-0.5 font-medium">نوع: Text (بُعد ثانوي)</span>
          </div>
          <div className="bg-white p-2.5 rounded-lg border border-slate-200/70">
            <span className="text-[10px] text-slate-400 block font-mono">Quantity</span>
            <span className="font-bold text-slate-850">الكمية المباعة</span>
            <span className="text-[10px] text-emerald-600 block mt-0.5 font-medium">نوع: Numeric (مقياس SUM)</span>
          </div>
          <div className="bg-white p-2.5 rounded-lg border border-slate-200/70">
            <span className="text-[10px] text-slate-400 block font-mono">Unit Price</span>
            <span className="font-bold text-slate-850">سعر الوحدة</span>
            <span className="text-[10px] text-emerald-600 block mt-0.5 font-medium">نوع: Currency (مقياس AVG)</span>
          </div>
          <div className="bg-white p-2.5 rounded-lg border border-slate-200/70">
            <span className="text-[10px] text-slate-400 block font-mono">Total Sales</span>
            <span className="font-bold text-slate-850">إجمالي المبيعات</span>
            <span className="text-[10px] text-emerald-600 block mt-0.5 font-medium">Qty × Price (مقياس SUM)</span>
          </div>
        </div>
      </div>

      {/* 3. Raw Data Table */}
      <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-bold text-slate-900">
              سجلات جدول البيانات الفعلي ({data.length} سجل)
            </h3>
          </div>
          <div className="w-full sm:w-64">
            <input
              type="text"
              placeholder="تصفية السجلات..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 focus:bg-white focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>
        </div>

        <div className="overflow-x-auto max-h-[500px]">
          <table className="w-full text-right text-xs">
            <thead className="bg-slate-50 text-slate-600 font-semibold sticky top-0 z-10 border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-3 w-10 text-center text-slate-400">#</th>
                <th className="py-2.5 px-3">رقم الفاتورة</th>
                <th className="py-2.5 px-3">التاريخ</th>
                <th className="py-2.5 px-3">المندوب</th>
                <th className="py-2.5 px-3">اسم العميل</th>
                <th className="py-2.5 px-3">الصنف / الدواء</th>
                <th className="py-2.5 px-3">الفئة</th>
                <th className="py-2.5 px-3 text-left">الكمية</th>
                <th className="py-2.5 px-3 text-left">سعر الوحدة</th>
                <th className="py-2.5 px-3 text-left">إجمالي المبيعات</th>
                <th className="py-2.5 px-3 text-center w-14">إجراء</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredRecords.length === 0 ? (
                <tr>
                  <td colSpan={11} className="py-8 text-center text-slate-400">
                    لا توجد سجلات مطابقة للبحث
                  </td>
                </tr>
              ) : (
                filteredRecords.map((r, idx) => (
                  <tr key={r.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-2.5 px-3 text-center text-slate-400 tabular-numbers">
                      {idx + 1}
                    </td>
                    <td className="py-2.5 px-3 font-mono text-[11px] text-slate-500">
                      {r.orderId}
                    </td>
                    <td className="py-2.5 px-3 text-slate-700 font-mono text-[11px]">
                      {r.date}
                    </td>
                    <td className="py-2.5 px-3 font-semibold text-blue-700 text-xs">
                      {r.salesRep || 'مصطفى محمد'}
                    </td>
                    <td className="py-2.5 px-3 font-bold text-slate-900">
                      {r.customerName}
                    </td>
                    <td className="py-2.5 px-3 text-slate-800">
                      <div>{r.itemName}</div>
                      {r.genericName && (
                        <div className="text-[10px] text-slate-400 font-mono">{r.genericName}</div>
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-slate-500">
                      {r.category}
                    </td>
                    <td className="py-2.5 px-3 text-left font-bold text-slate-800 tabular-numbers">
                      {formatNumber(r.quantity)}
                    </td>
                    <td className="py-2.5 px-3 text-left text-slate-700 tabular-numbers">
                      {formatCurrency(r.unitPrice, currency)}
                    </td>
                    <td className="py-2.5 px-3 text-left font-bold text-slate-900 tabular-numbers">
                      {formatCurrency(r.totalSales, currency)}
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => onViewInvoice(r)}
                          className="px-2 py-0.5 text-[10px] font-bold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded transition-colors cursor-pointer"
                          title="معاينة وطباعة الفاتورة كـ PDF"
                        >
                          PDF
                        </button>
                        <button
                          onClick={() => handleDeleteRecord(r.id)}
                          className="text-slate-400 hover:text-rose-600 transition-colors p-1 cursor-pointer"
                          title="حذف هذا الصف"
                        >
                          ✕
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
