import React, { useState } from 'react';
import { CurrencyCode, SalesRecord } from '../types';
import { formatCurrency, formatNumber } from '../utils/formatters';
import { APP_NAME, DEFAULT_SALES_REP, SUPPLIER_LINE } from '../data/productCatalog';

interface InvoicePdfModalProps {
  isOpen: boolean;
  onClose: () => void;
  record: SalesRecord | null;
  allRecords: SalesRecord[];
  onSelectRecord: (record: SalesRecord) => void;
  currency: CurrencyCode;
}

export const InvoicePdfModal: React.FC<InvoicePdfModalProps> = ({
  isOpen,
  onClose,
  record,
  allRecords,
  onSelectRecord,
  currency,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const currentRecord = record || allRecords[0];

  if (!currentRecord) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleCopyDetails = () => {
    const text = `فاتورة مبيعات - ${APP_NAME}
رقم الفاتورة: ${currentRecord.orderId}
التاريخ: ${currentRecord.date}
المندوب: ${currentRecord.salesRep || DEFAULT_SALES_REP}
العميل: ${currentRecord.customerName}
الصنف: ${currentRecord.itemName} (${currentRecord.genericName || ''})
الكمية: ${currentRecord.quantity} عبوة
سعر الوحدة: ${currentRecord.unitPrice}
الإجمالي: ${currentRecord.totalSales} ${currency}`;

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-900/70 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[95vh] shadow-2xl border border-slate-200 flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Top Bar (Hidden in Print) */}
        <div className="px-5 py-3.5 bg-slate-900 text-white flex items-center justify-between no-print">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center font-bold text-xs">
              PDF
            </div>
            <div>
              <h3 className="font-bold text-sm">معاينة وطباعة الفاتورة (Invoice PDF Viewer)</h3>
              <p className="text-[11px] text-slate-400">{APP_NAME} · {currentRecord.orderId}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Quick Invoice Selector */}
            <select
              value={currentRecord.id}
              onChange={(e) => {
                const found = allRecords.find((r) => r.id === e.target.value);
                if (found) onSelectRecord(found);
              }}
              className="bg-slate-800 text-slate-200 text-xs px-2.5 py-1.5 rounded-lg border border-slate-700 focus:outline-none cursor-pointer max-w-[180px] truncate"
            >
              {allRecords.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.orderId} - {r.customerName}
                </option>
              ))}
            </select>

            <button
              onClick={handleCopyDetails}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg transition-colors cursor-pointer border border-slate-700"
            >
              {copied ? '✓ تم النسخ' : 'نسخ النص'}
            </button>

            <button
              onClick={handlePrint}
              className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-lg transition-colors shadow-xs cursor-pointer flex items-center gap-1.5"
            >
              <span>طباعة الفاتورة / حفظ PDF</span>
            </button>

            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white p-1 text-lg font-bold cursor-pointer"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Printable Invoice Page Canvas */}
        <div className="flex-1 overflow-y-auto p-6 sm:p-8 bg-slate-100 flex justify-center">
          <div
            id="printable-invoice"
            className="bg-white w-full max-w-2xl shadow-md border border-slate-200 p-8 rounded-xl print-page font-sans text-slate-900"
          >
            {/* Invoice Header */}
            <div className="flex items-start justify-between border-b-2 border-slate-900 pb-5 mb-6">
              <div>
                <div className="inline-block px-2.5 py-0.5 bg-blue-100 text-blue-900 text-[11px] font-bold rounded mb-1">
                  فاتورة مبيعات رسمية · Tax Sales Invoice
                </div>
                <h1 className="text-2xl font-black text-slate-900 tracking-tight">
                  {APP_NAME}
                </h1>
                <p className="text-xs text-slate-600 font-medium mt-0.5">
                  {SUPPLIER_LINE}
                </p>
                <p className="text-[11px] text-slate-500 mt-1">
                  قسم التوزيع والمبيعات الدوائية · المملكة العربية السعودية / جمهورية السودان
                </p>
              </div>

              <div className="text-left dir-ltr">
                <div className="text-xl font-black text-blue-700 tracking-wide">
                  {currentRecord.orderId}
                </div>
                <div className="text-xs text-slate-500 font-mono mt-1">
                  Date: {currentRecord.date}
                </div>
                <div className="text-xs font-semibold text-slate-700 mt-0.5">
                  Rep: {currentRecord.salesRep || DEFAULT_SALES_REP}
                </div>
              </div>
            </div>

            {/* Bill To & Invoice Info Grid */}
            <div className="grid grid-cols-2 gap-4 p-4 bg-slate-50 border border-slate-200 rounded-xl mb-6 text-xs">
              <div>
                <span className="text-[10px] text-slate-400 font-bold block mb-1">
                  بيانات العميل والمشتري (Bill To):
                </span>
                <div className="font-bold text-slate-900 text-sm">
                  {currentRecord.customerName}
                </div>
                {currentRecord.customerSegment && (
                  <div className="text-[11px] text-slate-600 mt-0.5">
                    التصنيف: {currentRecord.customerSegment}
                  </div>
                )}
                <div className="text-[11px] text-slate-500 mt-0.5">
                  حالة الحساب: معتمد ومفعل
                </div>
              </div>

              <div>
                <span className="text-[10px] text-slate-400 font-bold block mb-1">
                  بيانات المعاملة والمندوب:
                </span>
                <div className="flex items-center justify-between text-[11px] py-0.5">
                  <span className="text-slate-500">اسم المندوب:</span>
                  <span className="font-bold text-slate-800">
                    {currentRecord.salesRep || DEFAULT_SALES_REP}
                  </span>
                </div>
                <div className="flex items-center justify-between text-[11px] py-0.5">
                  <span className="text-slate-500">تاريخ الإصدار:</span>
                  <span className="font-bold text-slate-800 font-mono">
                    {currentRecord.date}
                  </span>
                </div>
                <div className="flex items-center justify-between text-[11px] py-0.5">
                  <span className="text-slate-500">العملة المعتمدة:</span>
                  <span className="font-bold text-blue-700">{currency}</span>
                </div>
              </div>
            </div>

            {/* Line Items Table */}
            <div className="border border-slate-200 rounded-xl overflow-hidden mb-6">
              <table className="w-full text-right text-xs">
                <thead className="bg-slate-900 text-white font-bold">
                  <tr>
                    <th className="py-2.5 px-3 w-10 text-center">#</th>
                    <th className="py-2.5 px-3">الصنف الدوائي (Product Name)</th>
                    <th className="py-2.5 px-3">التركيب العلمي (Composition)</th>
                    <th className="py-2.5 px-3 text-center">الكمية</th>
                    <th className="py-2.5 px-3 text-left">سعر الوحدة</th>
                    <th className="py-2.5 px-3 text-left">الإجمالي</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  <tr className="bg-white">
                    <td className="py-3 px-3 text-center font-mono text-slate-400">1</td>
                    <td className="py-3 px-3 font-bold text-slate-900">
                      <div>{currentRecord.itemName}</div>
                      {currentRecord.boxCrt && (
                        <span className="text-[10px] text-slate-500 font-normal">
                          التعبئة: {currentRecord.boxCrt} عبوة/كرتونة
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-3 font-mono text-[11px] text-slate-600">
                      {currentRecord.genericName || '-'}
                    </td>
                    <td className="py-3 px-3 text-center font-bold text-slate-900 tabular-numbers">
                      {formatNumber(currentRecord.quantity)}{' '}
                      <span className="text-[10px] font-normal text-slate-400">عبوة</span>
                    </td>
                    <td className="py-3 px-3 text-left font-mono tabular-numbers text-slate-800">
                      {formatCurrency(currentRecord.unitPrice, currency)}
                    </td>
                    <td className="py-3 px-3 text-left font-bold text-slate-900 tabular-numbers">
                      {formatCurrency(currentRecord.totalSales, currency)}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Summary & Totals */}
            <div className="flex justify-between items-start gap-6 border-b border-slate-200 pb-6 mb-6">
              <div className="text-xs text-slate-500 max-w-xs space-y-1">
                {currentRecord.notes && (
                  <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-[11px]">
                    <span className="font-bold text-slate-700 block mb-0.5">ملاحظات الفاتورة:</span>
                    <span>{currentRecord.notes}</span>
                  </div>
                )}
                <p className="text-[10px] text-slate-400 mt-2">
                  * البضاعة المستلمة مطابقة للمواصفات القياسية الدوائية المعتمدة.
                </p>
              </div>

              {/* Total Box */}
              <div className="w-64 bg-slate-50 border border-slate-200 p-4 rounded-xl text-xs space-y-2">
                <div className="flex items-center justify-between text-slate-600">
                  <span>المجموع الفرعي:</span>
                  <span className="font-mono tabular-numbers">
                    {formatCurrency(currentRecord.totalSales, currency)}
                  </span>
                </div>
                <div className="flex items-center justify-between text-slate-600">
                  <span>الخصم الممنوح:</span>
                  <span className="font-mono tabular-numbers">0.00 {currency}</span>
                </div>
                <div className="border-t border-slate-300 pt-2 flex items-center justify-between text-base font-black text-slate-900">
                  <span>صافي الفاتورة:</span>
                  <span className="text-blue-700 tabular-numbers">
                    {formatCurrency(currentRecord.totalSales, currency)}
                  </span>
                </div>
              </div>
            </div>

            {/* Signatures Area */}
            <div className="grid grid-cols-2 gap-8 pt-4 text-xs text-slate-600">
              <div className="border-t border-dashed border-slate-300 pt-3 text-center">
                <div className="font-bold text-slate-800 mb-6">
                  مندوب المبيعات: {currentRecord.salesRep || DEFAULT_SALES_REP}
                </div>
                <div className="text-[10px] text-slate-400">التوقيع والاعتماد</div>
              </div>

              <div className="border-t border-dashed border-slate-300 pt-3 text-center">
                <div className="font-bold text-slate-800 mb-6">
                  استلام وختم العميل / الصيدلية
                </div>
                <div className="text-[10px] text-slate-400">التوقيع وتاريخ الاستلام</div>
              </div>
            </div>

            {/* Invoice Footer */}
            <div className="mt-8 pt-3 border-t border-slate-200 text-center text-[10px] text-slate-400">
              {APP_NAME} · تم إنشاء هذه الفاتورة رقمياً عبر منصة إدارة المبيعات · المندوب: {DEFAULT_SALES_REP}
            </div>
          </div>
        </div>

        {/* Modal Bottom Actions */}
        <div className="px-5 py-3 bg-white border-t border-slate-200 flex items-center justify-between no-print">
          <span className="text-xs text-slate-500">
            يمكنك طباعة الفاتورة على ورق A4 أو حفظها كملف PDF رقمي
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
            >
              إغلاق
            </button>
            <button
              onClick={handlePrint}
              className="px-5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg shadow-sm transition-colors cursor-pointer"
            >
              طباعة / حفظ PDF
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
