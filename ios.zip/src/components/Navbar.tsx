import React from 'react';
import { CurrencyCode } from '../types';

interface NavbarProps {
  activeTab: 'dashboard' | 'customers' | 'items' | 'dataSource' | 'lookerGuide';
  setActiveTab: (tab: 'dashboard' | 'customers' | 'items' | 'dataSource' | 'lookerGuide') => void;
  currency: CurrencyCode;
  setCurrency: (c: CurrencyCode) => void;
  onOpenAddModal: () => void;
  onOpenPriceModal: () => void;
  onOpenApkModal: () => void;
  onOpenInvoiceModal: () => void;
  recordCount: number;
  salesRepName: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  currency,
  setCurrency,
  onOpenAddModal,
  onOpenPriceModal,
  onOpenApkModal,
  onOpenInvoiceModal,
  recordCount,
  salesRepName,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-6 h-16">
          {/* Zone 1: Single text element wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white font-bold text-sm shadow-sm">
              مب
            </div>
            <a
              href="#dashboard"
              onClick={(e) => {
                e.preventDefault();
                setActiveTab('dashboard');
              }}
              className="text-lg font-black tracking-tight text-slate-900 whitespace-nowrap shrink-0 hover:text-blue-600 transition-colors"
            >
              مصطفى بترجي
            </a>
            {/* Sales Rep Badge */}
            <div className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 bg-blue-50 border border-blue-200/80 rounded-md text-xs font-semibold text-blue-900">
              <span className="text-[11px] text-blue-600 font-normal">المندوب:</span>
              <span>{salesRepName}</span>
            </div>
          </div>

          {/* Zone 2: 4-5 concise single-line text navigation links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`transition-colors whitespace-nowrap shrink-0 cursor-pointer pb-1 border-b-2 ${
                activeTab === 'dashboard'
                  ? 'border-blue-600 text-blue-600 font-semibold'
                  : 'border-transparent hover:text-slate-900 hover:border-slate-300'
              }`}
            >
              لوحة التقرير
            </button>
            <button
              onClick={() => setActiveTab('customers')}
              className={`transition-colors whitespace-nowrap shrink-0 cursor-pointer pb-1 border-b-2 ${
                activeTab === 'customers'
                  ? 'border-blue-600 text-blue-600 font-semibold'
                  : 'border-transparent hover:text-slate-900 hover:border-slate-300'
              }`}
            >
              تحليل العملاء
            </button>
            <button
              onClick={() => setActiveTab('items')}
              className={`transition-colors whitespace-nowrap shrink-0 cursor-pointer pb-1 border-b-2 ${
                activeTab === 'items'
                  ? 'border-blue-600 text-blue-600 font-semibold'
                  : 'border-transparent hover:text-slate-900 hover:border-slate-300'
              }`}
            >
              الأصناف والكميات
            </button>
            <button
              onClick={() => setActiveTab('dataSource')}
              className={`transition-colors whitespace-nowrap shrink-0 cursor-pointer pb-1 border-b-2 ${
                activeTab === 'dataSource'
                  ? 'border-blue-600 text-blue-600 font-semibold'
                  : 'border-transparent hover:text-slate-900 hover:border-slate-300'
              }`}
            >
              مصدر البيانات
            </button>
            <button
              onClick={() => setActiveTab('lookerGuide')}
              className={`transition-colors whitespace-nowrap shrink-0 cursor-pointer pb-1 border-b-2 ${
                activeTab === 'lookerGuide'
                  ? 'border-blue-600 text-blue-600 font-semibold'
                  : 'border-transparent hover:text-slate-900 hover:border-slate-300'
              }`}
            >
              دليل Looker Studio
            </button>
          </nav>

          {/* Zone 3: 1 primary action area */}
          <div className="flex items-center gap-2.5 shrink-0">
            {/* Price List Modifier Button */}
            <button
              onClick={onOpenPriceModal}
              className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5"
              title="تعديل وتخصيص أسعار الأصناف المعتمدة"
            >
              <span>تغيير الأسعار (11 صنف)</span>
            </button>

            {/* Invoice PDF Print Button */}
            <button
              onClick={onOpenInvoiceModal}
              className="px-2.5 sm:px-3 py-1.5 text-xs font-bold text-purple-800 bg-purple-50 hover:bg-purple-100 border border-purple-300 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1"
              title="معاينة وطباعة الفواتير PDF"
            >
              <span>طباعة فاتورة PDF 📄</span>
            </button>

            <div className="flex items-center border border-slate-200 rounded-lg p-0.5 bg-slate-50 text-xs font-medium text-slate-700">
              <span className="px-1.5 text-slate-500 hidden sm:inline">العملة:</span>
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
                className="bg-transparent text-slate-800 font-bold focus:outline-none cursor-pointer pr-1 pl-1 py-1"
                aria-label="اختيار العملة"
              >
                <option value="SDG">SDG (ج.س)</option>
                <option value="SAR">SAR (ر.س)</option>
                <option value="USD">USD ($)</option>
                <option value="AED">AED (د.إ)</option>
                <option value="EGP">EGP (ج.م)</option>
                <option value="EUR">EUR (€)</option>
              </select>
            </div>

            {/* iPhone / Mobile App Button */}
            <button
              onClick={onOpenApkModal}
              className="px-2.5 sm:px-3 py-1.5 text-xs font-bold text-slate-800 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1"
              title="تثبيت التطبيق للآيفون (iOS Safari) أو تحميل أندرويد"
            >
              <span>تطبيق الآيفون 🍏</span>
            </button>

            <button
              onClick={onOpenAddModal}
              className="px-3 sm:px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700 active:bg-blue-800 transition-colors whitespace-nowrap shrink-0 shadow-sm flex items-center gap-1.5 cursor-pointer"
            >
              <span>+ فاتورة بيع</span>
            </button>
          </div>
        </div>

        {/* Mobile Tab Bar */}
        <div className="flex md:hidden items-center justify-around py-2 border-t border-slate-100 overflow-x-auto text-xs">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`px-2 py-1 whitespace-nowrap rounded ${
              activeTab === 'dashboard' ? 'bg-blue-50 text-blue-600 font-bold' : 'text-slate-600'
            }`}
          >
            لوحة التقرير
          </button>
          <button
            onClick={() => setActiveTab('customers')}
            className={`px-2 py-1 whitespace-nowrap rounded ${
              activeTab === 'customers' ? 'bg-blue-50 text-blue-600 font-bold' : 'text-slate-600'
            }`}
          >
            العملاء
          </button>
          <button
            onClick={() => setActiveTab('items')}
            className={`px-2 py-1 whitespace-nowrap rounded ${
              activeTab === 'items' ? 'bg-blue-50 text-blue-600 font-bold' : 'text-slate-600'
            }`}
          >
            الأصناف
          </button>
          <button
            onClick={() => setActiveTab('dataSource')}
            className={`px-2 py-1 whitespace-nowrap rounded ${
              activeTab === 'dataSource' ? 'bg-blue-50 text-blue-600 font-bold' : 'text-slate-600'
            }`}
          >
            البيانات
          </button>
          <button
            onClick={() => setActiveTab('lookerGuide')}
            className={`px-2 py-1 whitespace-nowrap rounded ${
              activeTab === 'lookerGuide' ? 'bg-blue-50 text-blue-600 font-bold' : 'text-slate-600'
            }`}
          >
            دليل Looker
          </button>
        </div>
      </div>
    </header>
  );
};
