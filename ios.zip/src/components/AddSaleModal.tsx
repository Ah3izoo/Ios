import React, { useState } from 'react';
import { CurrencyCode, ProductItem, SalesRecord } from '../types';
import { DEFAULT_SALES_REP } from '../data/productCatalog';
import { formatCurrency } from '../utils/formatters';

interface AddSaleModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (record: Omit<SalesRecord, 'id'>) => void;
  catalog: ProductItem[];
  existingCustomers: string[];
  existingCategories: string[];
  currency?: CurrencyCode;
}

export const AddSaleModal: React.FC<AddSaleModalProps> = ({
  isOpen,
  onClose,
  onAdd,
  catalog,
  existingCustomers,
  existingCategories,
  currency = 'SDG',
}) => {
  const today = new Date().toISOString().split('T')[0];

  const firstProduct = catalog[0] || {
    productName: 'Acretin 0.05 cream',
    genericName: 'Tretinoin 0.05%',
    category: 'الجلدية والتجميل',
    currentPrice: 11981,
    defaultPrice: 11981,
  };

  const [date, setDate] = useState(today);
  const [customerName, setCustomerName] = useState('');
  const [selectedProductId, setSelectedProductId] = useState(firstProduct.id || '');
  const [itemName, setItemName] = useState(firstProduct.productName);
  const [genericName, setGenericName] = useState(firstProduct.genericName);
  const [category, setCategory] = useState(firstProduct.category);
  const [quantity, setQuantity] = useState<number>(10);
  const [unitPrice, setUnitPrice] = useState<number>(firstProduct.currentPrice);
  const [salesRep, setSalesRep] = useState(DEFAULT_SALES_REP);
  const [notes, setNotes] = useState('');
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const totalCalculated = quantity * unitPrice;

  const handleProductSelect = (prodId: string) => {
    setSelectedProductId(prodId);
    const prod = catalog.find((p) => p.id === prodId);
    if (prod) {
      setItemName(prod.productName);
      setGenericName(prod.genericName);
      setCategory(prod.category);
      setUnitPrice(prod.currentPrice);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim()) {
      setError('يرجى إدخال اسم العميل أو الصيدلية/المستشفى');
      return;
    }
    if (!itemName.trim()) {
      setError('يرجى اختيار الصنف أو الدواء');
      return;
    }
    if (quantity <= 0) {
      setError('يجب أن تكون الكمية أكبر من صفر');
      return;
    }
    if (unitPrice < 0) {
      setError('سعر الوحدة لا يمكن أن يكون سالباً');
      return;
    }

    const orderId = `INV-${Date.now().toString().slice(-5)}`;

    onAdd({
      orderId,
      date,
      customerName: customerName.trim(),
      itemName: itemName.trim(),
      genericName: genericName.trim(),
      category: category.trim() || 'عام',
      quantity,
      unitPrice,
      totalSales: totalCalculated,
      salesRep: salesRep.trim() || DEFAULT_SALES_REP,
      notes: notes.trim(),
    });

    onClose();
    // reset form
    setCustomerName('');
    setQuantity(10);
    setNotes('');
    setError('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-xl w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              تسجيل فاتورة / مبيعات جديدة (New Sales Invoice)
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              مبيعات الأدوية · المندوب: <span className="font-semibold text-blue-600">{DEFAULT_SALES_REP}</span>
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 text-lg font-bold p-1 cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-700 font-medium">
              {error}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Date */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                التاريخ (Date) *
              </label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
              />
            </div>

            {/* Sales Rep */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                اسم المندوب (Sales Representative) *
              </label>
              <input
                type="text"
                required
                value={salesRep}
                onChange={(e) => setSalesRep(e.target.value)}
                placeholder="مصطفى محمد"
                className="w-full text-xs bg-blue-50/50 border border-blue-300 font-bold text-blue-900 rounded-lg px-3 py-2 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              />
            </div>
          </div>

          {/* Customer Name */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              اسم العميل / الصيدلية / المستشفى (Customer Name) *
            </label>
            <input
              type="text"
              required
              list="customer-suggestions"
              value={customerName}
              onChange={(e) => {
                setCustomerName(e.target.value);
                if (error) setError('');
              }}
              placeholder="مثال: مجموعة صيدليات النهدي، مستشفى د. سليمان الحبيب..."
              className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 font-medium"
            />
            <datalist id="customer-suggestions">
              {existingCustomers.map((c) => (
                <option key={c} value={c} />
              ))}
            </datalist>
          </div>

          {/* Product Selection from Master List */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              الصنف / الدواء (كتالوج مصطفى بترجي - Betterjee Pharma) *
            </label>
            <select
              value={selectedProductId}
              onChange={(e) => handleProductSelect(e.target.value)}
              className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 font-bold cursor-pointer"
            >
              {catalog.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.productName} ({p.genericName}) - {p.currentPrice.toLocaleString()} W.Price
                </option>
              ))}
            </select>
          </div>

          {/* Quantity & Unit Price with Price change option */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                الكمية المباعة (Quantity) *
              </label>
              <input
                type="number"
                min="1"
                step="1"
                required
                value={quantity}
                onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 tabular-numbers font-bold"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold text-slate-700">
                  سعر الوحدة / الجملة (W.Price) *
                </label>
                <span className="text-[10px] text-blue-600 font-medium">قابل للتعديل</span>
              </div>
              <input
                type="number"
                min="0"
                step="any"
                required
                value={unitPrice}
                onChange={(e) => setUnitPrice(Math.max(0, parseFloat(e.target.value) || 0))}
                className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 tabular-numbers font-bold"
              />
            </div>
          </div>

          {/* Live Calculated Total Sales Banner */}
          <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-xl flex items-center justify-between">
            <div>
              <div className="text-xs font-semibold text-blue-900">
                إجمالي قيمة الفاتورة (Total Amount):
              </div>
              <div className="text-[11px] text-blue-700 font-mono">
                {quantity} عبوة × {unitPrice.toLocaleString()} =
              </div>
            </div>
            <div className="text-lg font-bold text-blue-700 tabular-numbers">
              {formatCurrency(totalCalculated, currency)}
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              ملاحظات الفاتورة (اختياري)
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="مثال: تسليم المستودع الرئيسي، خصم كميات..."
              className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm transition-colors cursor-pointer"
            >
              حفظ وتسجيل الفاتورة
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
