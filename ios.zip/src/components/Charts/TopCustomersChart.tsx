import React from 'react';
import { CurrencyCode, CustomerSummary } from '../../types';
import { formatCurrency, formatNumber, formatPercent } from '../../utils/formatters';

interface TopCustomersChartProps {
  customers: CustomerSummary[];
  currency: CurrencyCode;
  selectedCustomer: string;
  onSelectCustomer: (customerName: string) => void;
}

export const TopCustomersChart: React.FC<TopCustomersChartProps> = ({
  customers,
  currency,
  selectedCustomer,
  onSelectCustomer,
}) => {
  const top5 = customers.slice(0, 5);
  const maxSales = top5.length > 0 ? top5[0].totalSales : 1;

  return (
    <div className="bg-white rounded-xl border border-slate-200/90 p-5 shadow-xs flex flex-col justify-between">
      <div>
        <div className="flex items-center justify-between mb-1">
          <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
            <span>أعلى 5 عملاء شراءً (Top 5 Customers)</span>
            <span className="text-[10px] text-slate-400 font-mono">Bar Chart</span>
          </h3>
          <span className="text-xs text-blue-600 font-medium">
            حسب إجمالي المبيعات
          </span>
        </div>
        <p className="text-xs text-slate-500 mb-4">
          اضغط على أي عميل لتصفية كامل لوحة البيانات وفق مشترياته
        </p>

        {top5.length === 0 ? (
          <div className="flex items-center justify-center h-48 text-slate-400 text-xs">
            لا توجد بيانات مطابقة
          </div>
        ) : (
          <div className="space-y-3.5">
            {top5.map((c, idx) => {
              const widthPct = Math.max(8, (c.totalSales / maxSales) * 100);
              const isSelected = selectedCustomer === c.customerName;

              return (
                <div
                  key={c.customerName}
                  onClick={() =>
                    onSelectCustomer(isSelected ? '' : c.customerName)
                  }
                  className={`group p-2.5 rounded-lg border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-blue-50/80 border-blue-400 shadow-xs'
                      : 'bg-slate-50/60 border-slate-200/70 hover:bg-slate-100 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <div className="flex items-center gap-2 font-bold text-slate-850 truncate">
                      <span
                        className={`w-5 h-5 rounded-md flex items-center justify-center text-[10px] font-bold shrink-0 ${
                          idx === 0
                            ? 'bg-amber-100 text-amber-800'
                            : idx === 1
                            ? 'bg-slate-200 text-slate-700'
                            : idx === 2
                            ? 'bg-amber-50 text-amber-900'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {idx + 1}
                      </span>
                      <span className="truncate group-hover:text-blue-600 transition-colors">
                        {c.customerName}
                      </span>
                      {isSelected && (
                        <span className="text-[10px] font-medium text-blue-700 bg-blue-100/80 px-1.5 py-0.2 rounded">
                          محدد
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className="font-bold text-slate-900 tabular-numbers">
                        {formatCurrency(c.totalSales, currency)}
                      </span>
                      <span className="text-[11px] text-slate-400 font-mono">
                        ({formatPercent(c.percentageOfTotal)})
                      </span>
                    </div>
                  </div>

                  {/* Visual Bar */}
                  <div className="w-full bg-slate-200/80 rounded-full h-2 overflow-hidden flex">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        isSelected
                          ? 'bg-blue-600'
                          : idx === 0
                          ? 'bg-blue-600'
                          : 'bg-blue-500/80'
                      }`}
                      style={{ width: `${widthPct}%` }}
                    />
                  </div>

                  {/* Micro footer: items & orders */}
                  <div className="flex items-center justify-between text-[10px] text-slate-400 mt-1 pt-0.5">
                    <span>
                      {c.orderCount} فواتير · {formatNumber(c.totalQuantity)} وحدة
                    </span>
                    <span>
                      متوسط الطلب: {formatCurrency(c.avgOrderValue, currency)}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="flex items-center justify-between text-[11px] text-slate-400 pt-3 border-t border-slate-100 mt-4">
        <span>مقياس: SUM(Total Sales) مرتب تنازلياً</span>
        <span>حد العرض: Top 5 Dimensions</span>
      </div>
    </div>
  );
};
