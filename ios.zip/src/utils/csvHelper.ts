import { SalesRecord } from '../types';

export function exportToCSV(data: SalesRecord[], filename = 'sales_data_looker_studio.csv') {
  // UTF-8 BOM so Excel and Google Sheets open Arabic letters cleanly without mojibake
  const BOM = '\uFEFF';
  const headers = ['Order ID', 'Date', 'Sales Rep', 'Customer Name', 'Category', 'Item Name', 'Generic Name', 'Quantity', 'Unit Price', 'Total Sales', 'Notes'];
  
  const rows = data.map((item) => [
    `"${item.orderId || ''}"`,
    `"${item.date || ''}"`,
    `"${(item.salesRep || 'مصطفى محمد').replace(/"/g, '""')}"`,
    `"${(item.customerName || '').replace(/"/g, '""')}"`,
    `"${(item.category || '').replace(/"/g, '""')}"`,
    `"${(item.itemName || '').replace(/"/g, '""')}"`,
    `"${(item.genericName || '').replace(/"/g, '""')}"`,
    item.quantity,
    item.unitPrice,
    item.totalSales,
    `"${(item.notes || '').replace(/"/g, '""')}"`,
  ]);

  const csvContent = BOM + [headers.join(','), ...rows.map((r) => r.join(','))].join('\r\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function copyForGoogleSheets(data: SalesRecord[]): Promise<boolean> {
  const headers = ['التاريخ', 'المندوب', 'اسم العميل', 'الصنف / المنتج', 'الاسم العلمي', 'الفئة', 'الكمية المباعة', 'سعر الوحدة', 'إجمالي المبيعات', 'رقم الفاتورة'];
  const rows = data.map((item) => [
    item.date,
    item.salesRep || 'مصطفى محمد',
    item.customerName,
    item.itemName,
    item.genericName || '',
    item.category,
    item.quantity,
    item.unitPrice,
    item.totalSales,
    item.orderId,
  ]);

  const tsv = [headers.join('\t'), ...rows.map((r) => r.join('\t'))].join('\n');
  return navigator.clipboard.writeText(tsv).then(() => true).catch(() => false);
}

export function parseCSV(text: string): SalesRecord[] {
  // Remove BOM if present
  const cleaned = text.charCodeAt(0) === 0xFEFF ? text.slice(1) : text;
  const lines = cleaned.split(/\r?\n/).filter((l) => l.trim().length > 0);
  if (lines.length < 2) return [];

  // Parse header
  const headerLine = lines[0];
  const headers = splitCSVLine(headerLine).map((h) => h.trim().toLowerCase());

  // Detect column indexes
  const colDate = findColIndex(headers, ['date', 'التاريخ', 'تاريخ']);
  const colRep = findColIndex(headers, ['sales rep', 'rep', 'المندوب', 'اسم المندوب']);
  const colCustomer = findColIndex(headers, ['customer', 'customer name', 'العميل', 'اسم العميل']);
  const colItem = findColIndex(headers, ['item', 'item name', 'product', 'الصنف', 'المنتج', 'اسم الصنف']);
  const colGeneric = findColIndex(headers, ['generic', 'generic name', 'الاسم العلمي']);
  const colCategory = findColIndex(headers, ['category', 'الفئة', 'التصنيف', 'القسم']);
  const colQuantity = findColIndex(headers, ['quantity', 'qty', 'الكمية', 'الكمية المباعة']);
  const colPrice = findColIndex(headers, ['unit price', 'w.price', 'price', 'سعر الوحدة', 'السعر']);
  const colTotal = findColIndex(headers, ['total sales', 'total', 'amount', 'إجمالي المبيعات', 'الاجمالي', 'المبلغ']);
  const colOrderId = findColIndex(headers, ['order id', 'order', 'invoice', 'رقم الفاتورة', 'رقم الطلب']);

  const records: SalesRecord[] = [];

  for (let i = 1; i < lines.length; i++) {
    const rawCols = splitCSVLine(lines[i]);
    if (rawCols.length < 2) continue;

    const date = colDate !== -1 ? rawCols[colDate]?.trim() : new Date().toISOString().split('T')[0];
    const rep = colRep !== -1 ? rawCols[colRep]?.trim() : 'مصطفى محمد';
    const customer = colCustomer !== -1 ? rawCols[colCustomer]?.trim() : 'صيدلية عامة';
    const item = colItem !== -1 ? rawCols[colItem]?.trim() : 'صنف';
    const generic = colGeneric !== -1 ? rawCols[colGeneric]?.trim() : '';
    const category = colCategory !== -1 ? rawCols[colCategory]?.trim() : 'عام';
    const qty = colQuantity !== -1 ? Math.max(1, parseFloat(rawCols[colQuantity]) || 1) : 1;
    const price = colPrice !== -1 ? Math.max(0, parseFloat(rawCols[colPrice]) || 0) : 0;
    
    let total = colTotal !== -1 ? parseFloat(rawCols[colTotal]) : 0;
    if (isNaN(total) || total <= 0) {
      total = qty * price;
    }

    const orderId = colOrderId !== -1 && rawCols[colOrderId] ? rawCols[colOrderId].trim() : `INV-${1000 + i}`;

    records.push({
      id: `imported-${Date.now()}-${i}`,
      orderId,
      date,
      salesRep: rep || 'مصطفى محمد',
      customerName: customer || 'صيدلية عامة',
      category: category || 'عام',
      itemName: item || 'صنف',
      genericName: generic,
      quantity: qty,
      unitPrice: price,
      totalSales: total,
    });
  }

  return records;
}

function findColIndex(headers: string[], aliases: string[]): number {
  for (let i = 0; i < headers.length; i++) {
    const h = headers[i].replace(/["']/g, '').trim().toLowerCase();
    for (const alias of aliases) {
      if (h === alias || h.includes(alias)) return i;
    }
  }
  return -1;
}

function splitCSVLine(line: string): string[] {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;

  // Check if comma or tab separated
  const delimiter = line.includes('\t') && !line.includes(',') ? '\t' : ',';

  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    if (char === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === delimiter && !inQuotes) {
      result.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }
  result.push(current.trim());
  return result;
}
